using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Reflection;
using Microsoft.CSharp;
using Microsoft.VisualBasic;


namespace Phoenix.Runtime
{
    public static class Compiler
    {
        public enum Language
        {
            CSharp,
            VisualBasic
        }

        public static CompilerResults Compile(Language lang, string[] sourceFiles, string[] referencedAssemblies)
        {
            CodeDomProvider provider;

            switch (lang)
            {
                case Language.CSharp:
                    provider = new CSharpCodeProvider();
                    Debug.Assert(provider.FileExtension.ToLowerInvariant() == "cs");
                    break;

                case Language.VisualBasic:
                    provider = new VBCodeProvider();
                    Debug.Assert(provider.FileExtension.ToLowerInvariant() == "vb");
                    break;

                default:
                    throw new ArgumentException("Invalid language.");
            }

            CompilerParameters options = new CompilerParameters();
            options.GenerateExecutable = false;
            options.GenerateInMemory = true;
            options.IncludeDebugInformation = true;
            options.WarningLevel = 3;
            options.ReferencedAssemblies.Add("System.dll");
            options.ReferencedAssemblies.Add("System.Windows.Forms.dll");
            options.ReferencedAssemblies.Add("System.Drawing.dll");
            options.ReferencedAssemblies.Add("System.Xml.dll");
            options.ReferencedAssemblies.Add("System.Data.dll");
            options.ReferencedAssemblies.Add("Microsoft.VisualBasic.dll");

            foreach (string reference in referencedAssemblies)
            {
                options.ReferencedAssemblies.Add(reference);
            }

            CompilerResults result = CompileLanguage(sourceFiles, provider, options);

            provider.Dispose();

            return result;
        }

        private static CompilerResults CompileLanguage(string[] sourceFiles, CodeDomProvider provider, CompilerParameters options)
        {
            options.EmbeddedResources.Clear();
            options.LinkedResources.Clear();

            int codeFileCount = 0;
            List<String> files = new List<String>();

            foreach (string file in sourceFiles)
            {
                string ext = Path.GetExtension(file);
                if (String.Compare(ext, "." + provider.FileExtension, StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    files.Add(file);
                    codeFileCount++;
                }
                else if (ext.ToLowerInvariant() == ".resx")
                {
                    options.EmbeddedResources.Add(file);
                }
            }

            if (codeFileCount > 0)
            {
                try
                {
                    return provider.CompileAssemblyFromFile(options, files.ToArray());
                }
                catch { }
            }

            return null;
        }
    }
}
