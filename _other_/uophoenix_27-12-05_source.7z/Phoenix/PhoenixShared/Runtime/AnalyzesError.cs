using System;
using System.Collections.Generic;
using System.Text;

namespace Phoenix.Runtime.Compilation
{
    public struct AnalyzesError
    {
        private string type;
        private string description;
        private string attribute;

        public AnalyzesError(string type, string description)
        {
            this.type = type;
            this.description = description;
            this.attribute = "";
        }

        public AnalyzesError(string type, string description, string attribute)
        {
            this.type = type;
            this.description = description;
            this.attribute = attribute;
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public string Attribute
        {
            get { return attribute; }
            set { attribute = value; }
        }
    }
}
