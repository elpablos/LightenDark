using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Reflection;
using System.Diagnostics;

namespace Phoenix.Runtime.Compilation
{
    public class AssemblyAnalyzer
    {
        #region RuntimeAttribute dependece resolving

        private static readonly Type RuntimeAttributeType;
        private static readonly MethodInfo RegisterMethod;

        static AssemblyAnalyzer()
        {
            /* Assembly[] loadedAssemblies = AppDomain.CurrentDomain.GetAssemblies();

            Assembly PhoenixAssembly = null;
             
            foreach (Assembly assembly in loadedAssemblies)
            {
                if (assembly.FullName.StartsWith("Phoenix,"))
                {
                    PhoenixAssembly = assembly;
                    break;
                }
            }

            Debug.Assert(PhoenixAssembly != null, "Phoenix assembly not loaded. This library is not intended to be used directly!");

            RuntimeAttributeType = PhoenixAssembly.GetType("Phoenix.RuntimeAttribute");
            */
            RuntimeAttributeType = typeof(RuntimeAttribute);
            Debug.Assert(RuntimeAttributeType != null, "RuntimeAttribute not found.");

            RegisterMethod = RuntimeAttributeType.GetMethod("Register", BindingFlags.Instance | BindingFlags.NonPublic);
            Debug.Assert(RuntimeAttributeType != null, "Register method not found.");            
        }

        #endregion

        private List<AnalyzesError> errors;
        private StringCollection output;

        private int indentLevel;
        private int indentSize;
        private string indentString;

        public AssemblyAnalyzer()
        {
            errors = new List<AnalyzesError>();
            output = new StringCollection();

            indentLevel = 0;
            indentSize = 4;
            indentString = "";
        }

        public StringCollection Output
        {
            get { return output; }
        }

        public string OutputText
        {
            get
            {
                StringBuilder builder = new StringBuilder();

                for (int i = 0; i < output.Count; i++)
                {
                    builder.AppendLine(output[i]);
                }

                return builder.ToString();
            }
        }

        public List<AnalyzesError> Errors
        {
            get { return errors; }
        }

        protected int IndentLevel
        {
            get { return indentLevel; }
            set
            {
                indentLevel = value;
                UpdateIndentString();
            }
        }

        protected int IndentSize
        {
            get { return indentSize; }
            set
            {
                indentSize = value;
                UpdateIndentString();
            }
        }

        protected string IndentString
        {
            get { return indentString; }
        }

        private void UpdateIndentString()
        {
            indentString = "";
            for (int i = 0; i < indentLevel * indentSize; i++)
            {
                indentString += " ";
            }
        }

        public virtual void Clear()
        {
            errors.Clear();
            output.Clear();
        }

        public virtual void AnalyzeAndRegister(Assembly assembly)
        {
            IndentLevel = 0;

            TraceWriteLine("Analyzation of assembly \"{0}\" started.", assembly);
            Indent();

            Type[] types = assembly.GetExportedTypes();
            WriteLine("{0} exported types found.", types.Length);

            for (int i = 0; i < types.Length; i++)
            {
                AnalyzeType(types[i]);
            }

            Unindent();
            TraceWriteLine("Analyzation of assembly \"{0}\" finished.", assembly);
        }

        private void AnalyzeType(Type type)
        {
            WriteLine("Analyzing type {0}", type);
            Indent();

            Object target = null;

            // Check attribute on class itself
            if (type.IsDefined(RuntimeAttributeType, true))
            {
                AnalyzeClass(type, ref target);
            }
            else
            {
                WriteLine("RuntimeAttribute not set.");
            }


            MethodInfo[] methods = type.GetMethods(BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance);
            WriteLine("{0} methods found.", methods.Length);

            foreach (MethodInfo mi in methods)
            {
                if (mi.IsDefined(RuntimeAttributeType, true))
                {
                    try
                    {
                        WriteLine("Registering {0}.{1}()..", type.FullName, mi.Name);
                        Indent();

                        if (!mi.IsStatic && target == null)
                        {
                            try
                            {
                                target = type.Assembly.CreateInstance(type.FullName);
                            }
                            catch (Exception e)
                            {
                                throw new Exception("Error creating object instance.", e);
                            }
                        }

                        object[] attributes = mi.GetCustomAttributes(RuntimeAttributeType, true);

                        foreach (object a in attributes)
                        {
                            try
                            {
                                string msg = (string)RegisterMethod.Invoke(a, new object[] { mi, target });

                                if (msg != null && msg.Length > 0)
                                    WriteLine(msg);
                            }
                            catch (Exception e)
                            {
                                WriteError(type, e, a);
                            }
                        }

                        WriteLine("Successfully completed.");
                    }
                    catch (Exception e)
                    {
                        WriteError(type, e);
                    }
                    finally
                    {
                        Unindent();
                    }
                }
            }

            Unindent();
            WriteLine();
        }

        private void AnalyzeClass(Type type, ref Object target)
        {
            if (type.IsClass && !type.IsAbstract)
            {
                try
                {
                    WriteLine("RuntimeAttribute found. Registering..");
                    Indent();

                    try
                    {
                        target = type.Assembly.CreateInstance(type.FullName);
                    }
                    catch (Exception e)
                    {
                        throw new Exception("Error creating object instance.", e);
                    }

                    object[] attributes = type.GetCustomAttributes(RuntimeAttributeType, true);

                    foreach (object a in attributes)
                    {
                        try
                        {
                            string msg = (string)RegisterMethod.Invoke(a, new object[] { type, target });

                            if (msg != null && msg.Length > 0)
                                WriteLine(msg);
                        }
                        catch (Exception e)
                        {
                            WriteError(type, e, a);
                        }
                    }

                    WriteLine("Successfully completed.");
                }
                catch (Exception e)
                {
                    WriteError(type, e);
                }
                finally
                {
                    Unindent();
                }
            }
            else
            {
                WriteLine("Invalid use of RuntimeAttribute. Type is not class or it is abstract.");
            }
        }

        protected virtual void WriteLine()
        {
            output.Add("");
        }

        protected virtual void WriteLine(string format, params object[] args)
        {
            string message = indentString + String.Format(format, args);
            output.Add(message);
        }

        protected virtual void TraceWriteLine(string format, params object[] args)
        {
            string message = indentString + String.Format(format, args);
            Trace.WriteLine(message, "Runtime");
            output.Add(message);
        }

        protected virtual void WriteError(Type type, Exception e)
        {
            errors.Add(new AnalyzesError(type.ToString(), e.Message));
            WriteLine("Unhandled error:\n{0}", e);
        }

        protected virtual void WriteError(Type type, Exception e, object attribute)
        {
            errors.Add(new AnalyzesError(type.ToString(), e.Message, attribute.ToString()));
            WriteLine("Unhandled error:\n{0}", e);
        }

        protected void Indent()
        {
            IndentLevel++;
        }

        protected void Unindent()
        {
            IndentLevel--;
        }
    }
}
