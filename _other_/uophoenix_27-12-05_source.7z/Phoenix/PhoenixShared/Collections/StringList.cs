using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Text;

namespace Phoenix.Collections
{
    public class StringList : ListEx<String>
    {
        #region SynchronizedStringList class

        private class SynchronizedStringList : StringList
        {
            public SynchronizedStringList(IList<string> wrappedCollection)
                : base(wrappedCollection)
            {
            }

            public override bool IsSynchronized
            {
                get { return true; }
            }

            public override void AddRange(IEnumerable<string> collection)
            {
                lock (SyncRoot)
                {
                    base.AddRange(collection);
                }
            }

            public override void AddRange(StringCollection collection)
            {
                lock (SyncRoot)
                {
                    base.AddRange(collection);
                }
            }

            protected override void InsertItem(int index, string item)
            {
                lock (SyncRoot)
                {
                    base.InsertItem(index, item);
                }
            }

            protected override void SetItem(int index, string item)
            {
                lock (SyncRoot)
                {
                    base.SetItem(index, item);
                }
            }

            protected override void RemoveItem(int index)
            {
                lock (SyncRoot)
                {
                    base.RemoveItem(index);
                }
            }

            protected override void ClearItems()
            {
                lock (SyncRoot)
                {
                    base.ClearItems();
                }
            }

            public override string[] ToArray()
            {
                lock (SyncRoot)
                {
                    return base.ToArray();
                }
            }

            public override string ToString()
            {
                lock (SyncRoot)
                {
                    return base.ToString();
                }
            }
        }

        #endregion

        public StringList()
        {
        }

        protected StringList(IList<String> wrappedCollection)
            : base(wrappedCollection)
        {
        }

        public virtual void AddRange(StringCollection collection)
        {
            if (collection == null)
                throw new ArgumentNullException("collection");

            foreach (string item in collection)
            {
                Add(item);
            }
        }

        /// <summary>
        /// Returns string consisting from all elements each on one line.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder builder = new StringBuilder(Items.Count);
            for (int i = 0; i < Items.Count; i++)
            {
                builder.AppendLine(Items[i]);
            }
            return builder.ToString();
        }

        public static new StringList Synchronize(IList<String> list)
        {
            return new SynchronizedStringList(list);
        }
    }
}
