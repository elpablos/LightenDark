using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Reflection;
using System.CodeDom.Compiler;

namespace Phoenix.Collections
{
    public class CompilerErrorList : ListEx<CompilerError>
    {
        #region SynchronizedCompilerErrorList class

        private class SynchronizedCompilerErrorList : CompilerErrorList
        {
            public SynchronizedCompilerErrorList(IList<CompilerError> wrappedCollection)
                : base(wrappedCollection)
            {
            }

            public override bool IsSynchronized
            {
                get { return true; }
            }

            public override bool HasErrors
            {
                get
                {
                    lock (SyncRoot)
                    {
                        return base.HasErrors;
                    }
                }
            }

            public override bool HasWarnings
            {
                get
                {
                    lock (SyncRoot)
                    {
                        return base.HasWarnings;
                    }
                }
            }

            public override void AddRange(IEnumerable<CompilerError> collection)
            {
                lock (SyncRoot)
                {
                    base.AddRange(collection);
                }
            }

            public override void AddRange(CompilerErrorCollection collection)
            {
                lock (SyncRoot)
                {
                    base.AddRange(collection);
                }
            }

            protected override void InsertItem(int index, CompilerError item)
            {
                lock (SyncRoot)
                {
                    base.InsertItem(index, item);
                }
            }

            protected override void SetItem(int index, CompilerError item)
            {
                lock (SyncRoot)
                {
                    base.SetItem(index, item);
                }
            }

            protected override void RemoveItem(int index)
            {
                lock (SyncRoot)
                {
                    base.RemoveItem(index);
                }
            }

            protected override void ClearItems()
            {
                lock (SyncRoot)
                {
                    base.ClearItems();
                }
            }

            public override CompilerError[] ToArray()
            {
                lock (SyncRoot)
                {
                    return base.ToArray();
                }
            }

            public override string ToString()
            {
                lock (SyncRoot)
                {
                    return base.ToString();
                }
            }
        }

        #endregion

        public CompilerErrorList()
        {
        }

        protected CompilerErrorList(IList<CompilerError> wrappedCollection)
            : base(wrappedCollection)
        {
        }

        public virtual void AddRange(CompilerErrorCollection collection)
        {
            if (collection == null)
                throw new ArgumentNullException("collection");

            foreach (CompilerError item in collection)
            {
                Add(item);
            }
        }

        /// <summary>
        /// Gets a value that indicates whether the collection contains errors.
        /// </summary>
        public virtual bool HasErrors
        {
            get
            {
                for (int i = 0; i < Items.Count; i++)
                {
                    if (!Items[i].IsWarning)
                        return true;
                }
                return false;
            }
        }

        /// <summary>
        /// Gets a value that indicates whether the collection contains warnings.
        /// </summary>
        public virtual bool HasWarnings
        {
            get
            {
                for (int i = 0; i < Items.Count; i++)
                {
                    if (Items[i].IsWarning)
                        return true;
                }
                return false;
            }
        }

        public static new CompilerErrorList Synchronize(IList<CompilerError> list)
        {
            return new SynchronizedCompilerErrorList(list);
        }
    }
}
