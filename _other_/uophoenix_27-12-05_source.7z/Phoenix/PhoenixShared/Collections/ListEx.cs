using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace Phoenix.Collections
{
    public class ListItemChangeEventArgs<T> : EventArgs
    {
        private int index;
        private T item;

        public ListItemChangeEventArgs(int index, T item)
        {
            this.index = index;
            this.item = item;
        }

        /// <summary>
        /// Index of changed item;
        /// </summary>
        public int Index
        {
            get { return index; }
        }

        /// <summary>
        /// Changed item.
        /// </summary>
        public T Item
        {
            get { return item; }
        }
    }

    public delegate void ListItemChangeEventHandler<T>(object sender, ListItemChangeEventArgs<T> e);

    public class ListEx<T> : Collection<T>
    {
        #region SyncrhonizedListEx class

        private class SynchronizedListEx : ListEx<T>
        {
            public SynchronizedListEx(IList<T> wrappedCollection)
                : base(wrappedCollection)
            {
            }

            public override bool IsSynchronized
            {
                get { return true; }
            }

            public override void AddRange(IEnumerable<T> collection)
            {
                lock (SyncRoot)
                {
                    base.AddRange(collection);
                }
            }

            protected override void InsertItem(int index, T item)
            {
                lock (SyncRoot)
                {
                    base.InsertItem(index, item);
                }
            }

            protected override void SetItem(int index, T item)
            {
                lock (SyncRoot)
                {
                    base.SetItem(index, item);
                }
            }

            protected override void RemoveItem(int index)
            {
                lock (SyncRoot)
                {
                    base.RemoveItem(index);
                }
            }

            protected override void ClearItems()
            {
                lock (SyncRoot)
                {
                    base.ClearItems();
                }
            }

            public override T[] ToArray()
            {
                lock (SyncRoot)
                {
                    return base.ToArray();
                }
            }
        }

        #endregion

        private readonly object syncRoot = new object();
        public event ListItemChangeEventHandler<T> ItemInserting;
        public event ListItemChangeEventHandler<T> ItemInserted;
        public event ListItemChangeEventHandler<T> ItemUpdating;
        public event ListItemChangeEventHandler<T> ItemUpdated;
        public event ListItemChangeEventHandler<T> ItemRemoving;
        public event ListItemChangeEventHandler<T> ItemRemoved;
        public event EventHandler ListClearing;
        public event EventHandler ListCleared;

        public ListEx()
        {
        }

        protected ListEx(IList<T> wrappedCollection)
            : base(wrappedCollection)
        {
        }

        public object SyncRoot
        {
            get { return syncRoot; }
        }

        public virtual bool IsSynchronized
        {
            get { return false; }
        }

        protected virtual void OnItemInserting(ListItemChangeEventArgs<T> e)
        {
            SyncEvent.Invoke(ItemInserting, this, e);
        }

        protected virtual void OnItemInserted(ListItemChangeEventArgs<T> e)
        {
            SyncEvent.Invoke(ItemInserted, this, e);
        }

        protected virtual void OnItemUpdating(ListItemChangeEventArgs<T> e)
        {
            SyncEvent.Invoke(ItemUpdating, this, e);
        }

        protected virtual void OnItemUpdated(ListItemChangeEventArgs<T> e)
        {
            SyncEvent.Invoke(ItemUpdated, this, e);
        }

        protected virtual void OnItemRemoving(ListItemChangeEventArgs<T> e)
        {
            SyncEvent.Invoke(ItemRemoving, this, e);
        }

        protected virtual void OnItemRemoved(ListItemChangeEventArgs<T> e)
        {
            SyncEvent.Invoke(ItemRemoved, this, e);
        }

        protected virtual void OnListClearing(EventArgs e)
        {
            SyncEvent.Invoke(ListClearing, this, e);
        }

        protected virtual void OnListCleared(EventArgs e)
        {
            SyncEvent.Invoke(ListCleared, this, e);
        }

        protected override void InsertItem(int index, T item)
        {
            ListItemChangeEventArgs<T> e = new ListItemChangeEventArgs<T>(index, item);
            OnItemInserting(e);
            base.InsertItem(index, item);
            OnItemInserted(e);
        }

        protected override void SetItem(int index, T item)
        {
            ListItemChangeEventArgs<T> e = new ListItemChangeEventArgs<T>(index, item);
            OnItemUpdating(e);
            base.SetItem(index, item);
            OnItemUpdated(e);
        }

        protected override void RemoveItem(int index)
        {
            if (index >= 0 && index < Items.Count)
            {
                ListItemChangeEventArgs<T> e = new ListItemChangeEventArgs<T>(index, Items[index]);
                OnItemRemoving(e);
                base.RemoveItem(index);
                OnItemRemoved(e);
            }
        }

        protected override void ClearItems()
        {
            OnListClearing(EventArgs.Empty);
            base.ClearItems();
            OnListCleared(EventArgs.Empty);
        }

        public virtual void AddRange(IEnumerable<T> collection)
        {
            if (collection == null)
                throw new ArgumentNullException("collection");

            foreach (T item in collection)
            {
                Add(item);
            }
        }

        public virtual T[] ToArray()
        {
            T[] array = new T[Items.Count];
            for (int i = 0; i < Items.Count; i++)
            {
                array[i] = Items[i];
            }
            return array;
        }

        public static ListEx<T> Synchronize(IList<T> list)
        {
            return new SynchronizedListEx(list);
        }
    }
}
