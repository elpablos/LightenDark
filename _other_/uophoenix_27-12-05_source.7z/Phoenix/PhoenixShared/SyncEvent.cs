using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Windows.Forms;
using System.Reflection;

namespace Phoenix
{
    public static class SyncEvent
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="handler"></param>
        /// <param name="sender"></param>
        /// <param name="e">Remember that this instance is not affected by event handlers in ISynchronizeInvoke.</param>
        public static void Invoke(MulticastDelegate handler, object sender, EventArgs e)
        {
            if (handler != null)
            {
                object[] args = new object[] { sender, e };
                foreach (Delegate d in handler.GetInvocationList())
                {
                    ISynchronizeInvoke sync = d.Target as ISynchronizeInvoke;
                    if (sync != null && sync.InvokeRequired)
                    {
                        sync.BeginInvoke(d, args);
                    }
                    else
                        d.Method.Invoke(d.Target, args);
                }
            }
        }

        public static void InvokeSingle(Delegate method, object sender, EventArgs e)
        {
            if (method != null)
            {
                ISynchronizeInvoke sync = method.Target as ISynchronizeInvoke;
                if (sync != null && sync.InvokeRequired)
                {
                    sync.BeginInvoke(method, new object[] { sender, e });
                }
                else
                    method.Method.Invoke(method.Target, new object[] { sender, e });
            }
        }
    }
}
