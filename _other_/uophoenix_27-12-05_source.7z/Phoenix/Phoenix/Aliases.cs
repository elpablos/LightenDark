using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Reflection;
using Phoenix.Configuration;
using Phoenix.Runtime;

namespace Phoenix
{
    public static class Aliases
    {
        private static Dictionary<string, Serial> objects = new Dictionary<string, Serial>();

        private static Serial lastObject = Serial.Invalid;
        private static Serial lastTarget = Serial.Invalid;
        private static Serial lastAttack = Serial.Invalid;
        private static Serial recevingContainer = Serial.Invalid;

        /// <summary>
        /// Called by Phoenix.Initialize()
        /// </summary>
        internal static void Init()
        {
            Core.RegisterClientMessageCallback(0x06, new MessageCallback(OnObjectDoubleClick));
            Core.RegisterClientMessageCallback(0x12, new MessageCallback(OnUse));
            Core.RegisterClientMessageCallback(0xBF, new MessageCallback(OnGeneralCommand));
            Core.RegisterClientMessageCallback(0x05, new MessageCallback(OnAttack));
            Core.RegisterClientMessageCallback(0x6C, new MessageCallback(OnClientTarget));

            Core.Disconnected += new EventHandler(Core_Disconnected);
        }

        static void Core_Disconnected(object sender, EventArgs e)
        {
            objects.Clear();
        }

        public static Serial Self
        {
            get { return WorldData.World.PlayerSerial; }
        }

        public static Serial Backpack
        {
            get
            {
                uint serial = WorldData.World.RealPlayer.Layers[0x15];

                if (serial == 0)
                    return Serial.Invalid;
                else
                    return serial;
            }
        }

        public static Serial LastObject
        {
            get { return Aliases.lastObject; }
            set { Aliases.lastObject = value; }
        }

        public static Serial LastTarget
        {
            get { return Aliases.lastTarget; }
            set { Aliases.lastTarget = value; }
        }

        public static Serial LastAttack
        {
            get { return Aliases.lastAttack; }
            set { Aliases.lastAttack = value; }
        }

        public static Serial RecevingContainer
        {
            get { return Aliases.recevingContainer; }
            set { Aliases.recevingContainer = value; }
        }

        #region Client messages handling

        private static CallbackResult OnObjectDoubleClick(byte[] data, CallbackResult prevResult)
        {
            Aliases.lastObject = ByteConverter.LittleEndian.ToUInt32(data, 1);
            Debug.WriteLine("LastObject updated.", "Aliases");
            return CallbackResult.Normal;
        }

        private static CallbackResult OnUse(byte[] data, CallbackResult prevResult)
        {
            return CallbackResult.Normal;
        }

        private static CallbackResult OnGeneralCommand(byte[] data, CallbackResult prevResult)
        {
            return CallbackResult.Normal;
        }

        private static CallbackResult OnAttack(byte[] data, CallbackResult prevResult)
        {
            Aliases.lastAttack = ByteConverter.LittleEndian.ToUInt32(data, 1);
            Debug.WriteLine("LastAttack updated.", "Aliases");
            return CallbackResult.Normal;
        }

        private static CallbackResult OnClientTarget(byte[] data, CallbackResult prevResult)
        {
            Aliases.lastTarget = ByteConverter.LittleEndian.ToUInt32(data, 7);
            Debug.WriteLine("LastTarget updated.", "Aliases");
            return CallbackResult.Normal;
        }

        #endregion

        public static Serial GetObject(string name)
        {
            if (!Helper.CheckName(ref name, false))
                return Serial.Invalid;

            if (objects.ContainsKey(name))
                return objects[name];

            PropertyInfo property = typeof(Aliases).GetProperty(name, BindingFlags.IgnoreCase | BindingFlags.Static | BindingFlags.Public);
            if (property != null)
            {
                return (Serial)property.GetValue(null, new object[0]);
            }
            else
            {
                return Serial.Invalid;
            }
        }

        public static bool ObjectExists(string name)
        {
            if (!Helper.CheckName(ref name, false))
                return false;

            if (objects.ContainsKey(name))
                return true;

            PropertyInfo property = typeof(Aliases).GetProperty(name, BindingFlags.IgnoreCase | BindingFlags.Static | BindingFlags.Public);
            if (property != null)
            {
                object o = property.GetValue(null, new object[0]);
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// This function ins provided only for compatilibity with Injection. If you can avoid it don't use it.
        /// Objects are deleted on logout.
        /// </summary>
        /// <param name="name">Can contain only letters. It is not case sensitive.</param>
        public static void SetObject(string name, Serial value)
        {
            Helper.CheckName(ref name, true);

            PropertyInfo property = typeof(Aliases).GetProperty(name, BindingFlags.IgnoreCase | BindingFlags.Static | BindingFlags.Public);
            if (property != null)
            {
                property.SetValue(null, value, new object[0]);
            }
            else
            {
                objects[name] = value;
            }
        }

        /// <summary>
        /// This function ins provided only for compatilibity with Injection. If you can avoid it don't use it.
        /// Objects are deleted on logout.
        /// </summary>
        /// <param name="name">Can contain only letters. It is not case sensitive.</param>
        public static void DeleteObject(string name)
        {
            if (!Helper.CheckName(ref name, false))
                return;

            PropertyInfo property = typeof(Aliases).GetProperty(name, BindingFlags.IgnoreCase | BindingFlags.Static | BindingFlags.Public);
            if (property != null)
            {
                property.SetValue(null, Serial.Invalid, new object[0]);
            }
            else
            {
                objects.Remove(name);
            }
        }
    }
}
