namespace Phoenix.Gui.Pages
{
    partial class RuntimePage
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.runningListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.terminateButton = new System.Windows.Forms.Button();
            this.terminateAllButton = new System.Windows.Forms.Button();
            this.commandbox = new System.Windows.Forms.TextBox();
            this.runButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // runningListBox
            // 
            this.runningListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.runningListBox.FormattingEnabled = true;
            this.runningListBox.IntegralHeight = false;
            this.runningListBox.Location = new System.Drawing.Point(3, 19);
            this.runningListBox.Name = "runningListBox";
            this.runningListBox.Size = new System.Drawing.Size(261, 188);
            this.runningListBox.TabIndex = 0;
            this.runningListBox.SelectedIndexChanged += new System.EventHandler(this.runningListBox_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Running functions:";
            // 
            // terminateButton
            // 
            this.terminateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.terminateButton.Enabled = false;
            this.terminateButton.Location = new System.Drawing.Point(104, 213);
            this.terminateButton.Name = "terminateButton";
            this.terminateButton.Size = new System.Drawing.Size(75, 23);
            this.terminateButton.TabIndex = 2;
            this.terminateButton.Text = "Terminate";
            this.terminateButton.Click += new System.EventHandler(this.terminateButton_Click);
            // 
            // terminateAllButton
            // 
            this.terminateAllButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.terminateAllButton.Location = new System.Drawing.Point(185, 213);
            this.terminateAllButton.Name = "terminateAllButton";
            this.terminateAllButton.Size = new System.Drawing.Size(79, 23);
            this.terminateAllButton.TabIndex = 3;
            this.terminateAllButton.Text = "Terminate All";
            this.terminateAllButton.Click += new System.EventHandler(this.terminateAllButton_Click);
            // 
            // commandbox
            // 
            this.commandbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.commandbox.Location = new System.Drawing.Point(3, 242);
            this.commandbox.Name = "commandbox";
            this.commandbox.Size = new System.Drawing.Size(219, 20);
            this.commandbox.TabIndex = 5;
            this.commandbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.commandbox_KeyDown);
            // 
            // runButton
            // 
            this.runButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.runButton.Location = new System.Drawing.Point(228, 242);
            this.runButton.Name = "runButton";
            this.runButton.Size = new System.Drawing.Size(36, 20);
            this.runButton.TabIndex = 6;
            this.runButton.Text = "Run";
            this.runButton.Click += new System.EventHandler(this.runButton_Click);
            // 
            // RuntimePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.runButton);
            this.Controls.Add(this.commandbox);
            this.Controls.Add(this.terminateAllButton);
            this.Controls.Add(this.terminateButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.runningListBox);
            this.Name = "RuntimePage";
            this.Size = new System.Drawing.Size(267, 265);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox runningListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button terminateButton;
        private System.Windows.Forms.Button terminateAllButton;
        private System.Windows.Forms.TextBox commandbox;
        private System.Windows.Forms.Button runButton;
    }
}
