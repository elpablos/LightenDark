using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace Phoenix.Gui.Pages._Log
{
    class LogBoxWriterTraceListener : TraceListener
    {
        private LogBox richTextBox;

        public LogBoxWriterTraceListener(LogBox richTextBox)
        {
            this.richTextBox = richTextBox;
        }

        /*
                private void TrimText()
                {
                    if (richTextBox.Lines.Length > MaxLines)
                    {
                        richTextBox.Select(0, richTextBox.GetFirstCharIndexFromLine(5));
                        richTextBox.SelectedText = "";
                    }
                }
        */

        public override void Write(string message, string category)
        {
            base.Write(message, category);
        }

        public override void WriteLine(string message, string category)
        {
            richTextBox.Write(message + "\n", category);
        }

        public override void Write(string message)
        {
            richTextBox.Write(message);
        }

        public override void WriteLine(string message)
        {
            richTextBox.Write(message + "\n");
        }
    }
}
