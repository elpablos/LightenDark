using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Phoenix.Gui.Controls;

namespace Phoenix.Gui.Pages._Log
{
    [ToolboxItem(false)]
    class LogBox : RichTextBoxEx
    {
        private readonly object syncRoot = new object();
        private IntPtr safeHandle = IntPtr.Zero;
        private Queue<KeyValuePair<string, string>> updateQueue = new Queue<KeyValuePair<string, string>>();
        private Dictionary<string, LogCategoryInfo> categories = new Dictionary<string, LogCategoryInfo>();
        private bool autoScroll;

        /// <summary>
        /// Default c..tor
        /// </summary>
        public LogBox()
        {
            categories.Add("Other", new LogCategoryInfo(true, System.Drawing.Color.Black));
            autoScroll = true;
        }

        [Category("Appearance")]
        [DefaultValue(true)]
        public bool AutoScroll
        {
            get { return autoScroll; }
            set { autoScroll = value; }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            safeHandle = Handle;

            base.OnHandleCreated(e);

            if (updateQueue.Count > 0)
            {
                Native.PostMessage(safeHandle, Native.WM_UPDATECONTENTS, 0, 0);
            }
        }

        protected override void OnHandleDestroyed(EventArgs e)
        {
            safeHandle = IntPtr.Zero;

            base.OnHandleDestroyed(e);
        }

        protected bool IsSafeHandleCreated
        {
            get { return safeHandle != IntPtr.Zero; }
        }

        public Dictionary<string, LogCategoryInfo> Categories
        {
            get { return categories; }
            set { categories = value; }
        }

        public void Write(string message)
        {
            lock (syncRoot)
            {
                updateQueue.Enqueue(new KeyValuePair<string, string>(null, message));
            }

            if (IsSafeHandleCreated)
            {
                Native.PostMessage(safeHandle, Native.WM_UPDATECONTENTS, 0, 0);
            }
        }

        public void Write(string message, string category)
        {
            lock (syncRoot)
            {
                updateQueue.Enqueue(new KeyValuePair<string, string>(category, message));
            }

            if (IsSafeHandleCreated)
            {
                Native.PostMessage(safeHandle, Native.WM_UPDATECONTENTS, 0, 0);
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == Native.WM_UPDATECONTENTS)
            {
                while (updateQueue.Count > 0)
                {
                    KeyValuePair<string, string> entry;

                    lock (syncRoot)
                    {
                        entry = updateQueue.Dequeue();
                    }

                    OnUpdateContents(entry);
                }

                m.Result = IntPtr.Zero;
            }
            else
            {
                base.WndProc(ref m);
            }
        }

        protected virtual void OnUpdateContents(KeyValuePair<string, string> entry)
        {
            if (entry.Value != null)
            {
                State state = GetState();

                try
                {
                    LockWindowUpdate();

                    if (entry.Key != null)
                    {
                        LogCategoryInfo info;

                        if (categories.ContainsKey(entry.Key))
                            info = categories[entry.Key];
                        else
                            info = categories["Other"];

                        if (info.Enabled)
                        {
                            SetColor(TextLength, 0, info.Color);
                            AppendText(entry.Key);

                            SetColor(TextLength, 0, ForeColor);
                            AppendText(": " + entry.Value);
                        }
                    }
                    else
                    {
                        SetColor(TextLength, 0, ForeColor);
                        AppendText(entry.Value);
                    }
                }
                finally
                {
                    UnlockWindowUpdate();
                }

                // Handle scrolling
                if (autoScroll)
                    ScrollToBottom();
                else
                    SetState(state);
            }
        }
    }
}
