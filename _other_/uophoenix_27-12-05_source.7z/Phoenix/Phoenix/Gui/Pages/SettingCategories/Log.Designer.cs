namespace Phoenix.Gui.Pages.SettingCategories
{
    partial class Log
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Log));
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.serverPhoenixBox = new Phoenix.Gui.Controls.SettingEntryCheckBox();
            this.phoenixClientBox = new Phoenix.Gui.Controls.SettingEntryCheckBox();
            this.phoenixServerBox = new Phoenix.Gui.Controls.SettingEntryCheckBox();
            this.clientPhoenixBox = new Phoenix.Gui.Controls.SettingEntryCheckBox();
            this.labelLine1 = new Phoenix.Gui.Controls.LabelLine();
            this.packetLoggingBox = new Phoenix.Gui.Controls.SettingEntryCheckBox();
            this.SuspendLayout();
            // 
            // serverPhoenixBox
            // 
            this.serverPhoenixBox.AccessibleDescription = resources.GetString("serverPhoenixBox.AccessibleDescription");
            this.serverPhoenixBox.AccessibleName = resources.GetString("serverPhoenixBox.AccessibleName");
            resources.ApplyResources(this.serverPhoenixBox, "serverPhoenixBox");
            this.serverPhoenixBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("serverPhoenixBox.BackgroundImage")));
            this.serverPhoenixBox.Font = ((System.Drawing.Font)(resources.GetObject("serverPhoenixBox.Font")));
            this.serverPhoenixBox.Name = "serverPhoenixBox";
            this.serverPhoenixBox.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("serverPhoenixBox.RightToLeft")));
            this.serverPhoenixBox.SettingEntry = null;
            this.toolTip.SetToolTip(this.serverPhoenixBox, resources.GetString("serverPhoenixBox.ToolTip"));
            // 
            // phoenixClientBox
            // 
            this.phoenixClientBox.AccessibleDescription = resources.GetString("phoenixClientBox.AccessibleDescription");
            this.phoenixClientBox.AccessibleName = resources.GetString("phoenixClientBox.AccessibleName");
            resources.ApplyResources(this.phoenixClientBox, "phoenixClientBox");
            this.phoenixClientBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("phoenixClientBox.BackgroundImage")));
            this.phoenixClientBox.Font = ((System.Drawing.Font)(resources.GetObject("phoenixClientBox.Font")));
            this.phoenixClientBox.Name = "phoenixClientBox";
            this.phoenixClientBox.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("phoenixClientBox.RightToLeft")));
            this.phoenixClientBox.SettingEntry = null;
            this.toolTip.SetToolTip(this.phoenixClientBox, resources.GetString("phoenixClientBox.ToolTip"));
            // 
            // phoenixServerBox
            // 
            this.phoenixServerBox.AccessibleDescription = resources.GetString("phoenixServerBox.AccessibleDescription");
            this.phoenixServerBox.AccessibleName = resources.GetString("phoenixServerBox.AccessibleName");
            resources.ApplyResources(this.phoenixServerBox, "phoenixServerBox");
            this.phoenixServerBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("phoenixServerBox.BackgroundImage")));
            this.phoenixServerBox.Font = ((System.Drawing.Font)(resources.GetObject("phoenixServerBox.Font")));
            this.phoenixServerBox.Name = "phoenixServerBox";
            this.phoenixServerBox.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("phoenixServerBox.RightToLeft")));
            this.phoenixServerBox.SettingEntry = null;
            this.toolTip.SetToolTip(this.phoenixServerBox, resources.GetString("phoenixServerBox.ToolTip"));
            // 
            // clientPhoenixBox
            // 
            this.clientPhoenixBox.AccessibleDescription = resources.GetString("clientPhoenixBox.AccessibleDescription");
            this.clientPhoenixBox.AccessibleName = resources.GetString("clientPhoenixBox.AccessibleName");
            resources.ApplyResources(this.clientPhoenixBox, "clientPhoenixBox");
            this.clientPhoenixBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("clientPhoenixBox.BackgroundImage")));
            this.clientPhoenixBox.Font = ((System.Drawing.Font)(resources.GetObject("clientPhoenixBox.Font")));
            this.clientPhoenixBox.Name = "clientPhoenixBox";
            this.clientPhoenixBox.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("clientPhoenixBox.RightToLeft")));
            this.clientPhoenixBox.SettingEntry = null;
            this.toolTip.SetToolTip(this.clientPhoenixBox, resources.GetString("clientPhoenixBox.ToolTip"));
            // 
            // labelLine1
            // 
            this.labelLine1.AccessibleDescription = resources.GetString("labelLine1.AccessibleDescription");
            this.labelLine1.AccessibleName = resources.GetString("labelLine1.AccessibleName");
            resources.ApplyResources(this.labelLine1, "labelLine1");
            this.labelLine1.Font = ((System.Drawing.Font)(resources.GetObject("labelLine1.Font")));
            this.labelLine1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.labelLine1.LineColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelLine1.Margin = new System.Windows.Forms.Padding(3);
            this.labelLine1.Name = "labelLine1";
            this.labelLine1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("labelLine1.RightToLeft")));
            this.toolTip.SetToolTip(this.labelLine1, resources.GetString("labelLine1.ToolTip"));
            // 
            // packetLoggingBox
            // 
            this.packetLoggingBox.AccessibleDescription = resources.GetString("packetLoggingBox.AccessibleDescription");
            this.packetLoggingBox.AccessibleName = resources.GetString("packetLoggingBox.AccessibleName");
            resources.ApplyResources(this.packetLoggingBox, "packetLoggingBox");
            this.packetLoggingBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("packetLoggingBox.BackgroundImage")));
            this.packetLoggingBox.Font = ((System.Drawing.Font)(resources.GetObject("packetLoggingBox.Font")));
            this.packetLoggingBox.Name = "packetLoggingBox";
            this.packetLoggingBox.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("packetLoggingBox.RightToLeft")));
            this.packetLoggingBox.SettingEntry = null;
            this.toolTip.SetToolTip(this.packetLoggingBox, resources.GetString("packetLoggingBox.ToolTip"));
            // 
            // Log
            // 
            this.AccessibleDescription = resources.GetString("$this.AccessibleDescription");
            this.AccessibleName = resources.GetString("$this.AccessibleName");
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.Controls.Add(this.serverPhoenixBox);
            this.Controls.Add(this.phoenixClientBox);
            this.Controls.Add(this.phoenixServerBox);
            this.Controls.Add(this.clientPhoenixBox);
            this.Controls.Add(this.labelLine1);
            this.Controls.Add(this.packetLoggingBox);
            this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
            this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
            this.Name = "Log";
            this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
            this.toolTip.SetToolTip(this, resources.GetString("$this.ToolTip"));
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip;
        private Phoenix.Gui.Controls.SettingEntryCheckBox serverPhoenixBox;
        private Phoenix.Gui.Controls.SettingEntryCheckBox phoenixClientBox;
        private Phoenix.Gui.Controls.SettingEntryCheckBox phoenixServerBox;
        private Phoenix.Gui.Controls.SettingEntryCheckBox clientPhoenixBox;
        private Phoenix.Gui.Controls.LabelLine labelLine1;
        private Phoenix.Gui.Controls.SettingEntryCheckBox packetLoggingBox;
    }
}
