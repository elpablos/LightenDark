using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Phoenix.Runtime;

namespace Phoenix.Gui.Pages
{
    [PhoenixWindowTabPage("Phoenix.Properties.Resources.Page_Runtime", TitleIsResource = true, Position = 6, Icon = "Phoenix.Properties.Resources.RuntimeIcon")]
    public partial class RuntimePage : UserControl
    {
        public RuntimePage()
        {
            InitializeComponent();

            RuntimeCore.Executions.ExecutionStarted += new ExecutionsChangedEventHandler(Executions_ExecutionStarted);
            RuntimeCore.Executions.ExecutionFinished += new ExecutionsChangedEventHandler(Executions_ExecutionFinished);
        }

        void Executions_ExecutionStarted(object sender, ExecutionsChangedEventArgs e)
        {
            runningListBox.Items.Add(e.ExecutionInfo);
        }

        void Executions_ExecutionFinished(object sender, ExecutionsChangedEventArgs e)
        {
            runningListBox.Items.Remove(e.ExecutionInfo);
        }

        private void runningListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            terminateButton.Enabled = runningListBox.SelectedItem != null;
        }

        private void terminateButton_Click(object sender, EventArgs e)
        {
            if (runningListBox.SelectedItem != null)
            {
                ExecutionInfo ei = (ExecutionInfo)runningListBox.SelectedItem;
                ei.Thread.Abort();
            }

            terminateButton.Enabled = runningListBox.SelectedItem != null;
        }

        private void terminateAllButton_Click(object sender, EventArgs e)
        {
            RuntimeCore.Executions.TerminateAll();
        }


        private void runButton_Click(object sender, EventArgs e)
        {
            Run();
        }

        private void commandbox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && e.Modifiers == Keys.None)
            {
                Run();
                e.SuppressKeyPress = true;
            }
        }

        private void Run()
        {
            TextCommand command = TextCommand.Parse(commandbox.Text);

            if (RuntimeCore.CommandList.Contains(command.Command))
            {
                RuntimeCore.Executions.Execute(RuntimeCore.CommandList[command.Command], command.Arguments);
            }
            else
            {
                UO.PrintError("Unknown command {0}.", command.Command);
            }
        }
    }
}
