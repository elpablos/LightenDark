namespace Phoenix.Gui.Pages
{
    partial class InfoPageOLD
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InfoPageOLD));
            this.phoenixGroup = new System.Windows.Forms.GroupBox();
            this.phoenixIcon = new Phoenix.Gui.Controls.IconBox();
            this.label2 = new System.Windows.Forms.Label();
            this.versionBox = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.serverGroup = new System.Windows.Forms.GroupBox();
            this.shardBox = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.addressBox = new System.Windows.Forms.Label();
            this.encryptionBox = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.communicationGroup = new System.Windows.Forms.GroupBox();
            this.pingBox = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.upTotalBox = new System.Windows.Forms.Label();
            this.downTotalBox = new System.Windows.Forms.Label();
            this.timeConnectedBox = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.averageUpBandBox = new System.Windows.Forms.Label();
            this.averageDownBandBox = new System.Windows.Forms.Label();
            this.upBandBox = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.downBandBox = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.playerGroup = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.staminaBox = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.hitsBox = new System.Windows.Forms.Label();
            this.manabox = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.accountBox = new System.Windows.Forms.Label();
            this.characterBox = new System.Windows.Forms.Label();
            this.positionBox = new System.Windows.Forms.Label();
            this.worldGroup = new System.Windows.Forms.GroupBox();
            this.charCountBox = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.itemCountBox = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.latencyTestTimer = new System.Windows.Forms.Timer(this.components);
            this.dummyMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.phoenixGroup.SuspendLayout();
            this.serverGroup.SuspendLayout();
            this.communicationGroup.SuspendLayout();
            this.playerGroup.SuspendLayout();
            this.worldGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // phoenixGroup
            // 
            this.phoenixGroup.Controls.Add(this.phoenixIcon);
            this.phoenixGroup.Controls.Add(this.label2);
            this.phoenixGroup.Controls.Add(this.versionBox);
            this.phoenixGroup.Controls.Add(this.label1);
            this.phoenixGroup.Location = new System.Drawing.Point(3, 0);
            this.phoenixGroup.Margin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.phoenixGroup.Name = "phoenixGroup";
            this.phoenixGroup.Size = new System.Drawing.Size(281, 60);
            this.phoenixGroup.TabIndex = 0;
            this.phoenixGroup.TabStop = false;
            this.phoenixGroup.Text = "Phoenix";
            // 
            // phoenixIcon
            // 
            this.phoenixIcon.BackColor = System.Drawing.Color.Transparent;
            this.phoenixIcon.BackgroundImage = null;
            this.phoenixIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.phoenixIcon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.phoenixIcon.ForeColor = System.Drawing.Color.Transparent;
            this.phoenixIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("phoenixIcon.Icon")));
            this.phoenixIcon.Location = new System.Drawing.Point(6, 19);
            this.phoenixIcon.Name = "phoenixIcon";
            this.phoenixIcon.Size = new System.Drawing.Size(32, 32);
            this.phoenixIcon.TabIndex = 4;
            this.phoenixIcon.Text = "IconBox";
            this.phoenixIcon.MouseClick += new System.Windows.Forms.MouseEventHandler(this.phoenixIcon_MouseClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 38);
            this.label2.Margin = new System.Windows.Forms.Padding(3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Copyright 2005 Mikee The Wanderer";
            // 
            // versionBox
            // 
            this.versionBox.AutoSize = true;
            this.versionBox.Location = new System.Drawing.Point(137, 19);
            this.versionBox.Margin = new System.Windows.Forms.Padding(3);
            this.versionBox.Name = "versionBox";
            this.versionBox.Size = new System.Drawing.Size(36, 13);
            this.versionBox.TabIndex = 2;
            this.versionBox.Text = "0.0.0.0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 19);
            this.label1.Margin = new System.Windows.Forms.Padding(3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Assembly version:";
            // 
            // serverGroup
            // 
            this.serverGroup.Controls.Add(this.shardBox);
            this.serverGroup.Controls.Add(this.label13);
            this.serverGroup.Controls.Add(this.addressBox);
            this.serverGroup.Controls.Add(this.encryptionBox);
            this.serverGroup.Controls.Add(this.label3);
            this.serverGroup.Controls.Add(this.label4);
            this.serverGroup.Cursor = System.Windows.Forms.Cursors.Default;
            this.serverGroup.Location = new System.Drawing.Point(3, 63);
            this.serverGroup.Margin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.serverGroup.Name = "serverGroup";
            this.serverGroup.Size = new System.Drawing.Size(281, 74);
            this.serverGroup.TabIndex = 13;
            this.serverGroup.TabStop = false;
            this.serverGroup.Text = "Server";
            // 
            // shardBox
            // 
            this.shardBox.AutoSize = true;
            this.shardBox.Location = new System.Drawing.Point(68, 54);
            this.shardBox.Name = "shardBox";
            this.shardBox.Size = new System.Drawing.Size(47, 13);
            this.shardBox.TabIndex = 6;
            this.shardBox.Text = "unknown";
            this.toolTip.SetToolTip(this.shardBox, "Shard you are currently logged on.");
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 54);
            this.label13.Margin = new System.Windows.Forms.Padding(3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 13);
            this.label13.TabIndex = 5;
            this.label13.Text = "Name:";
            this.toolTip.SetToolTip(this.label13, "Shard you are currently logged on.");
            // 
            // addressBox
            // 
            this.addressBox.AutoSize = true;
            this.addressBox.Location = new System.Drawing.Point(68, 16);
            this.addressBox.Name = "addressBox";
            this.addressBox.Size = new System.Drawing.Size(47, 13);
            this.addressBox.TabIndex = 4;
            this.addressBox.Text = "unknown";
            this.toolTip.SetToolTip(this.addressBox, "Server address.");
            // 
            // encryptionBox
            // 
            this.encryptionBox.AutoSize = true;
            this.encryptionBox.Location = new System.Drawing.Point(68, 35);
            this.encryptionBox.Name = "encryptionBox";
            this.encryptionBox.Size = new System.Drawing.Size(47, 13);
            this.encryptionBox.TabIndex = 3;
            this.encryptionBox.Text = "unknown";
            this.toolTip.SetToolTip(this.encryptionBox, "Server encryption name.");
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 35);
            this.label3.Margin = new System.Windows.Forms.Padding(3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Encryption:";
            this.toolTip.SetToolTip(this.label3, "Server encryption name.");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 16);
            this.label4.Margin = new System.Windows.Forms.Padding(3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Address:";
            this.toolTip.SetToolTip(this.label4, "Server address.");
            // 
            // communicationGroup
            // 
            this.communicationGroup.Controls.Add(this.pingBox);
            this.communicationGroup.Controls.Add(this.label16);
            this.communicationGroup.Controls.Add(this.label20);
            this.communicationGroup.Controls.Add(this.upTotalBox);
            this.communicationGroup.Controls.Add(this.downTotalBox);
            this.communicationGroup.Controls.Add(this.timeConnectedBox);
            this.communicationGroup.Controls.Add(this.label21);
            this.communicationGroup.Controls.Add(this.label22);
            this.communicationGroup.Controls.Add(this.averageUpBandBox);
            this.communicationGroup.Controls.Add(this.averageDownBandBox);
            this.communicationGroup.Controls.Add(this.upBandBox);
            this.communicationGroup.Controls.Add(this.label19);
            this.communicationGroup.Controls.Add(this.label15);
            this.communicationGroup.Controls.Add(this.downBandBox);
            this.communicationGroup.Controls.Add(this.label11);
            this.communicationGroup.Location = new System.Drawing.Point(3, 140);
            this.communicationGroup.Margin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.communicationGroup.Name = "communicationGroup";
            this.communicationGroup.Size = new System.Drawing.Size(281, 119);
            this.communicationGroup.TabIndex = 16;
            this.communicationGroup.TabStop = false;
            this.communicationGroup.Text = "Communication";
            // 
            // pingBox
            // 
            this.pingBox.AutoSize = true;
            this.pingBox.Location = new System.Drawing.Point(209, 98);
            this.pingBox.Name = "pingBox";
            this.pingBox.Size = new System.Drawing.Size(25, 13);
            this.pingBox.TabIndex = 29;
            this.pingBox.Text = "0 ms";
            this.pingBox.DoubleClick += new System.EventHandler(this.pingBox_DoubleClick);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(159, 98);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 13);
            this.label16.TabIndex = 28;
            this.label16.Text = "Latency:";
            this.label16.DoubleClick += new System.EventHandler(this.pingBox_DoubleClick);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(2, 76);
            this.label20.Margin = new System.Windows.Forms.Padding(3);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(30, 13);
            this.label20.TabIndex = 27;
            this.label20.Text = "Total:";
            // 
            // upTotalBox
            // 
            this.upTotalBox.Location = new System.Drawing.Point(159, 76);
            this.upTotalBox.Name = "upTotalBox";
            this.upTotalBox.Size = new System.Drawing.Size(59, 13);
            this.upTotalBox.TabIndex = 26;
            this.upTotalBox.Text = "unknown";
            this.upTotalBox.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // downTotalBox
            // 
            this.downTotalBox.Location = new System.Drawing.Point(61, 76);
            this.downTotalBox.Name = "downTotalBox";
            this.downTotalBox.Size = new System.Drawing.Size(59, 13);
            this.downTotalBox.TabIndex = 25;
            this.downTotalBox.Text = "unknown";
            this.downTotalBox.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // timeConnectedBox
            // 
            this.timeConnectedBox.AutoSize = true;
            this.timeConnectedBox.Location = new System.Drawing.Point(92, 98);
            this.timeConnectedBox.Name = "timeConnectedBox";
            this.timeConnectedBox.Size = new System.Drawing.Size(24, 13);
            this.timeConnectedBox.TabIndex = 24;
            this.timeConnectedBox.Text = "0:00";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 98);
            this.label21.Margin = new System.Windows.Forms.Padding(3);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(83, 13);
            this.label21.TabIndex = 23;
            this.label21.Text = "Time connected:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(2, 57);
            this.label22.Margin = new System.Windows.Forms.Padding(3);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(46, 13);
            this.label22.TabIndex = 22;
            this.label22.Text = "Average:";
            // 
            // averageUpBandBox
            // 
            this.averageUpBandBox.Location = new System.Drawing.Point(159, 57);
            this.averageUpBandBox.Name = "averageUpBandBox";
            this.averageUpBandBox.Size = new System.Drawing.Size(59, 13);
            this.averageUpBandBox.TabIndex = 21;
            this.averageUpBandBox.Text = "unknown";
            this.averageUpBandBox.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // averageDownBandBox
            // 
            this.averageDownBandBox.Location = new System.Drawing.Point(61, 57);
            this.averageDownBandBox.Name = "averageDownBandBox";
            this.averageDownBandBox.Size = new System.Drawing.Size(59, 13);
            this.averageDownBandBox.TabIndex = 20;
            this.averageDownBandBox.Text = "unknown";
            this.averageDownBandBox.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // upBandBox
            // 
            this.upBandBox.Location = new System.Drawing.Point(159, 38);
            this.upBandBox.Name = "upBandBox";
            this.upBandBox.Size = new System.Drawing.Size(59, 13);
            this.upBandBox.TabIndex = 10;
            this.upBandBox.Text = "unknown";
            this.upBandBox.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.Location = new System.Drawing.Point(167, 19);
            this.label19.Margin = new System.Windows.Forms.Padding(3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 13);
            this.label19.TabIndex = 9;
            this.label19.Text = "Upload";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(2, 38);
            this.label15.Margin = new System.Windows.Forms.Padding(3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "Bandwidth:";
            // 
            // downBandBox
            // 
            this.downBandBox.Location = new System.Drawing.Point(61, 38);
            this.downBandBox.Name = "downBandBox";
            this.downBandBox.Size = new System.Drawing.Size(59, 13);
            this.downBandBox.TabIndex = 6;
            this.downBandBox.Text = "unknown";
            this.downBandBox.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.Location = new System.Drawing.Point(61, 19);
            this.label11.Margin = new System.Windows.Forms.Padding(3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 13);
            this.label11.TabIndex = 5;
            this.label11.Text = "Download";
            // 
            // playerGroup
            // 
            this.playerGroup.Controls.Add(this.label12);
            this.playerGroup.Controls.Add(this.staminaBox);
            this.playerGroup.Controls.Add(this.label10);
            this.playerGroup.Controls.Add(this.label14);
            this.playerGroup.Controls.Add(this.hitsBox);
            this.playerGroup.Controls.Add(this.manabox);
            this.playerGroup.Controls.Add(this.label8);
            this.playerGroup.Controls.Add(this.label7);
            this.playerGroup.Controls.Add(this.label5);
            this.playerGroup.Controls.Add(this.accountBox);
            this.playerGroup.Controls.Add(this.characterBox);
            this.playerGroup.Controls.Add(this.positionBox);
            this.playerGroup.Location = new System.Drawing.Point(3, 262);
            this.playerGroup.Margin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.playerGroup.Name = "playerGroup";
            this.playerGroup.Size = new System.Drawing.Size(281, 76);
            this.playerGroup.TabIndex = 14;
            this.playerGroup.TabStop = false;
            this.playerGroup.Text = "Player";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(182, 35);
            this.label12.Margin = new System.Windows.Forms.Padding(3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 13);
            this.label12.TabIndex = 19;
            this.label12.Text = "Mana:";
            // 
            // staminaBox
            // 
            this.staminaBox.AutoSize = true;
            this.staminaBox.Location = new System.Drawing.Point(221, 54);
            this.staminaBox.Name = "staminaBox";
            this.staminaBox.Size = new System.Drawing.Size(47, 13);
            this.staminaBox.TabIndex = 22;
            this.staminaBox.Text = "unknown";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(182, 16);
            this.label10.Margin = new System.Windows.Forms.Padding(3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Hits:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(182, 54);
            this.label14.Margin = new System.Windows.Forms.Padding(3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 13);
            this.label14.TabIndex = 21;
            this.label14.Text = "Stam:";
            // 
            // hitsBox
            // 
            this.hitsBox.AutoSize = true;
            this.hitsBox.Location = new System.Drawing.Point(221, 16);
            this.hitsBox.Name = "hitsBox";
            this.hitsBox.Size = new System.Drawing.Size(47, 13);
            this.hitsBox.TabIndex = 18;
            this.hitsBox.Text = "unknown";
            // 
            // manabox
            // 
            this.manabox.AutoSize = true;
            this.manabox.Location = new System.Drawing.Point(221, 35);
            this.manabox.Name = "manabox";
            this.manabox.Size = new System.Drawing.Size(47, 13);
            this.manabox.TabIndex = 20;
            this.manabox.Text = "unknown";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 54);
            this.label8.Margin = new System.Windows.Forms.Padding(3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Position:";
            this.toolTip.SetToolTip(this.label8, "Your position in X.Y.Z format.\r\nNever trust Z value, if you really need it use re" +
                    "sync first.");
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 35);
            this.label7.Margin = new System.Windows.Forms.Padding(3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Character:";
            this.toolTip.SetToolTip(this.label7, "Name of currently logged character.");
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 16);
            this.label5.Margin = new System.Windows.Forms.Padding(3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Account:";
            this.toolTip.SetToolTip(this.label5, "Name of currently logged account.");
            // 
            // accountBox
            // 
            this.accountBox.AutoSize = true;
            this.accountBox.Location = new System.Drawing.Point(68, 16);
            this.accountBox.Name = "accountBox";
            this.accountBox.Size = new System.Drawing.Size(47, 13);
            this.accountBox.TabIndex = 6;
            this.accountBox.Text = "unknown";
            this.toolTip.SetToolTip(this.accountBox, "Name of currently logged account.");
            // 
            // characterBox
            // 
            this.characterBox.AutoSize = true;
            this.characterBox.Location = new System.Drawing.Point(68, 35);
            this.characterBox.Name = "characterBox";
            this.characterBox.Size = new System.Drawing.Size(47, 13);
            this.characterBox.TabIndex = 8;
            this.characterBox.Text = "unknown";
            this.toolTip.SetToolTip(this.characterBox, "Name of currently logged character.");
            // 
            // positionBox
            // 
            this.positionBox.AutoSize = true;
            this.positionBox.Location = new System.Drawing.Point(68, 54);
            this.positionBox.Name = "positionBox";
            this.positionBox.Size = new System.Drawing.Size(47, 13);
            this.positionBox.TabIndex = 10;
            this.positionBox.Text = "unknown";
            this.toolTip.SetToolTip(this.positionBox, "Your position in X.Y.Z format.\r\nNever trust Z value, if you really need it use re" +
                    "sync first.");
            // 
            // worldGroup
            // 
            this.worldGroup.Controls.Add(this.charCountBox);
            this.worldGroup.Controls.Add(this.label9);
            this.worldGroup.Controls.Add(this.label6);
            this.worldGroup.Controls.Add(this.itemCountBox);
            this.worldGroup.Location = new System.Drawing.Point(3, 341);
            this.worldGroup.Margin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.worldGroup.Name = "worldGroup";
            this.worldGroup.Size = new System.Drawing.Size(281, 56);
            this.worldGroup.TabIndex = 15;
            this.worldGroup.TabStop = false;
            this.worldGroup.Text = "World";
            // 
            // charCountBox
            // 
            this.charCountBox.AutoSize = true;
            this.charCountBox.Location = new System.Drawing.Point(94, 35);
            this.charCountBox.Name = "charCountBox";
            this.charCountBox.Size = new System.Drawing.Size(9, 13);
            this.charCountBox.TabIndex = 12;
            this.charCountBox.Text = "0";
            this.toolTip.SetToolTip(this.charCountBox, "Count of items that Phoenix currently holds in memory.");
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 16);
            this.label9.Margin = new System.Windows.Forms.Padding(3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Item count:";
            this.toolTip.SetToolTip(this.label9, "Count of items that Phoenix currently holds in memory.");
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 35);
            this.label6.Margin = new System.Windows.Forms.Padding(3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Character count:";
            this.toolTip.SetToolTip(this.label6, "Count of items that Phoenix currently holds in memory.");
            // 
            // itemCountBox
            // 
            this.itemCountBox.AutoSize = true;
            this.itemCountBox.Location = new System.Drawing.Point(94, 16);
            this.itemCountBox.Name = "itemCountBox";
            this.itemCountBox.Size = new System.Drawing.Size(9, 13);
            this.itemCountBox.TabIndex = 10;
            this.itemCountBox.Text = "0";
            this.toolTip.SetToolTip(this.itemCountBox, "Count of items that Phoenix currently holds in memory.");
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 250;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // latencyTestTimer
            // 
            this.latencyTestTimer.Interval = 500;
            this.latencyTestTimer.Tick += new System.EventHandler(this.latencyTestTimer_Tick);
            // 
            // dummyMenuStrip
            // 
            this.dummyMenuStrip.Enabled = true;
            this.dummyMenuStrip.GripMargin = new System.Windows.Forms.Padding(2);
            this.dummyMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.dummyMenuStrip.Name = "dummyMenuStrip";
            this.dummyMenuStrip.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dummyMenuStrip.Size = new System.Drawing.Size(61, 4);
            this.dummyMenuStrip.Opening += new System.ComponentModel.CancelEventHandler(this.dummyMenuStrip_Opening);
            // 
            // InfoPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ContextMenuStrip = this.dummyMenuStrip;
            this.Controls.Add(this.phoenixGroup);
            this.Controls.Add(this.serverGroup);
            this.Controls.Add(this.communicationGroup);
            this.Controls.Add(this.playerGroup);
            this.Controls.Add(this.worldGroup);
            this.Name = "InfoPage";
            this.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.Size = new System.Drawing.Size(287, 415);
            this.Load += new System.EventHandler(this.InfoPage_Load);
            this.phoenixGroup.ResumeLayout(false);
            this.phoenixGroup.PerformLayout();
            this.serverGroup.ResumeLayout(false);
            this.serverGroup.PerformLayout();
            this.communicationGroup.ResumeLayout(false);
            this.communicationGroup.PerformLayout();
            this.playerGroup.ResumeLayout(false);
            this.playerGroup.PerformLayout();
            this.worldGroup.ResumeLayout(false);
            this.worldGroup.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox phoenixGroup;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label versionBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox serverGroup;
        private System.Windows.Forms.Label shardBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label addressBox;
        private System.Windows.Forms.Label encryptionBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox communicationGroup;
        private System.Windows.Forms.Label upBandBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label downBandBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox playerGroup;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label staminaBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label hitsBox;
        private System.Windows.Forms.Label manabox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label accountBox;
        private System.Windows.Forms.Label characterBox;
        private System.Windows.Forms.Label positionBox;
        private System.Windows.Forms.GroupBox worldGroup;
        private System.Windows.Forms.Label charCountBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label itemCountBox;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label upTotalBox;
        private System.Windows.Forms.Label downTotalBox;
        private System.Windows.Forms.Label timeConnectedBox;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label averageUpBandBox;
        private System.Windows.Forms.Label averageDownBandBox;
        private System.Windows.Forms.Label pingBox;
        private System.Windows.Forms.Label label16;
        private Phoenix.Gui.Controls.IconBox phoenixIcon;
        private System.Windows.Forms.Timer latencyTestTimer;
        private System.Windows.Forms.ContextMenuStrip dummyMenuStrip;
    }
}
