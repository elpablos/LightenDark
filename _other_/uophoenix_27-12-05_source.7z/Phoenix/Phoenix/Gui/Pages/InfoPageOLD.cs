using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using Crownwood.Magic.Menus;
using Phoenix.WorldData;

namespace Phoenix.Gui.Pages
{
    public partial class InfoPageOLD : UserControl
    {
        private const int WM_RBUTTONUP = 0x0205;

        private const int PingTestCount = 20;

        private PopupMenu popupMenu;
        private MenuCommand customizeMenuCommand;

        private DateTime lastTime = DateTime.Now;
        private TimeSpan timeConnected = new TimeSpan();
        private DateTime lastPingTest = new DateTime();
        private int pingTestCount = 0;

        public InfoPageOLD()
        {
            InitializeComponent();

            popupMenu = new PopupMenu();

            customizeMenuCommand = new MenuCommand("Customize");
            customizeMenuCommand.Description = "Allows you to customize Info tab page.";
            customizeMenuCommand.Click += new EventHandler(customizeMenuCommand_Click);

            popupMenu.MenuCommands.Add(customizeMenuCommand);

            ResetData();

            encryptionBox.Text = Core.LaunchData.ServerEncName;

            LoginInfo.Changed += new EventHandler(LoginInfo_Changed);
            Core.LoginComplete += new EventHandler(Core_LoginComplete);
            Core.Disconnected += new EventHandler(Core_Disconnected);
            Phoenix.Communication.CommunicationManager.BandwidthManager.BandwidthChanged += new EventHandler(BandwidthManager_BandwidthChanged);

            Phoenix.Communication.LatencyMeasurement.LatencyChanged += new EventHandler(LatencyMeasurement_LatencyChanged);
        }

        private void UpdateLayout()
        {
            HorizontalScroll.Enabled = false;

            Point pt = new Point(3, -VerticalScroll.Value);

            foreach (Control control in Controls)
            {
                GroupBox group = control as GroupBox;
                if (group != null && group.Visible)
                {
                    group.Location = pt;
                    group.Width = this.ClientRectangle.Width - 6;
                    pt.Offset(0, group.Height + 3);
                }
            }
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            UpdateLayout();
            base.OnVisibleChanged(e);
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            UpdateLayout();
            base.OnSizeChanged(e);
        }

        void customizeMenuCommand_Click(object sender, EventArgs e)
        {
            InfoCustomizeDialog dlg = new InfoCustomizeDialog();

            if (dlg.ShowDialog() == DialogResult.OK)
            {
            }

            dlg.Dispose();
        }

        void LatencyMeasurement_LatencyChanged(object sender, EventArgs e)
        {
            string text = Core.Latency.ToString() + " ms";
            System.Drawing.Color color = Helper.GetStatusColor((float)Core.Latency / 250.0f, 150);

            pingBox.Text = text;
            pingBox.ForeColor = color;
        }

        void Core_LoginComplete(object sender, EventArgs e)
        {
            World.Player.Changed += new ObjectChangedEventHandler(Player_Changed);
        }

        void Core_Disconnected(object sender, EventArgs e)
        {
            ResetData();
        }

        private void InfoPage_Load(object sender, EventArgs e)
        {
            versionBox.Text = Core.Version.ToString();

#if DEBUG
            versionBox.Text += " Debug";
#endif
        }

        void Player_Changed(object sender, ObjectChangedEventArgs e)
        {
            if (e.Type == ObjectChangeType.CharUpdated)
            {
                hitsBox.Text = String.Format("{0}/{1}", World.RealPlayer.Hits, World.RealPlayer.MaxHits);
                manabox.Text = String.Format("{0}/{1}", World.RealPlayer.Mana, World.RealPlayer.MaxMana);
                staminaBox.Text = String.Format("{0}/{1}", World.RealPlayer.Stamina, World.RealPlayer.MaxStamina);
                positionBox.Text = String.Format("{0}.{1}.{2}", World.RealPlayer.X, World.RealPlayer.Y, World.RealPlayer.Z);
                characterBox.Text = World.RealPlayer.Name;
            }
        }

        void LoginInfo_Changed(object sender, EventArgs e)
        {
            addressBox.Text = LoginInfo.Address.ToString();
            shardBox.Text = LoginInfo.Shard;

            accountBox.Text = LoginInfo.Account;
            characterBox.Text = LoginInfo.Player;
        }

        void BandwidthManager_BandwidthChanged(object sender, EventArgs e)
        {
            Phoenix.Communication.BandwidthManager man = Phoenix.Communication.CommunicationManager.BandwidthManager;
            upBandBox.Text = SizeConverter.ToOptimal(man.UploadBandwidth);
            upTotalBox.Text = SizeConverter.ToOptimal(man.TotalUpload);
            downBandBox.Text = SizeConverter.ToOptimal(man.DownloadBandwidth);
            downTotalBox.Text = SizeConverter.ToOptimal(man.TotalDownload);

            if ((long)timeConnected.TotalSeconds > 0)
            {
                averageUpBandBox.Text = SizeConverter.ToOptimal(man.TotalUpload / (long)timeConnected.TotalSeconds);
                averageDownBandBox.Text = SizeConverter.ToOptimal(man.TotalDownload / (long)timeConnected.TotalSeconds);
            }
            else
            {
                averageUpBandBox.Text = SizeConverter.ToOptimal(0);
                averageDownBandBox.Text = SizeConverter.ToOptimal(0);
            }
        }

        private void ResetData()
        {
            hitsBox.ResetText();
            manabox.ResetText();
            staminaBox.ResetText();
            positionBox.ResetText();

            shardBox.ResetText();

            accountBox.ResetText();
            characterBox.ResetText();

            addressBox.Text = Core.LaunchData.Address;
            pingBox.Text = "0 ms";
            pingBox.ForeColor = System.Drawing.Color.FromArgb(0, 0, 150);
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            if (Phoenix.Communication.CommunicationManager.Connected)
            {
                timeConnected += time - lastTime;
            }
            lastTime = time;

            if (IsHandleCreated)
            {
                int itemCount = World.ItemList.Count;
                int charCount = World.CharList.Count;
                itemCountBox.Text = itemCount.ToString();
                charCountBox.Text = charCount.ToString();

                timeConnectedBox.Text = String.Format("{0}:{1:00}:{2:00}", timeConnected.Hours, timeConnected.Minutes, timeConnected.Seconds);
            }
        }

        private void pingBox_DoubleClick(object sender, EventArgs e)
        {
            if (Core.LoggedIn)
            {
                TimeSpan interval = new TimeSpan(0, 1, 0);
                TimeSpan elapsed = DateTime.Now - lastPingTest;
                if (elapsed > interval)
                {
                    pingTestCount = 0;
                    latencyTestTimer.Enabled = true;
                    lastPingTest = DateTime.Now;
                    UO.PrintInformation("Ping test started.");
                }
                else
                {
                    TimeSpan remaining = interval - elapsed;
                    UO.PrintWarning("You cannot test ping yet. Time remaining: {0}:{1:00}", remaining.Minutes, remaining.Seconds);
                }
            }
        }

        private void latencyTestTimer_Tick(object sender, EventArgs e)
        {
            Phoenix.Communication.LatencyMeasurement.SendPing();
            pingTestCount++;

            if (pingTestCount > PingTestCount)
            {
                latencyTestTimer.Enabled = false;
            }
        }

        private void dummyMenuStrip_Opening(object sender, CancelEventArgs e)
        {
            e.Cancel = true;

            popupMenu.TrackPopup(Control.MousePosition);
        }

        private void phoenixIcon_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                string address = Config.Settings.GetElement(Core.HomepageUrl, "Config", "Homepage");
                Helper.OpenBroswer(address);
            }
        }
    }
}
