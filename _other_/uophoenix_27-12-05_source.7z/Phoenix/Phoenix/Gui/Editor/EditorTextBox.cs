using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Drawing;

namespace Phoenix.Gui.Editor
{
    public class EditorTextBox : Phoenix.Gui.Controls.RichTextBoxEx
    {
        private const int WM_KEYFIRST = 0x0100;
        private const int WM_KEYDOWN = 0x0100;
        private const int WM_KEYUP = 0x0101;
        private const int WM_CHAR = 0x0102;

        private List<string> keywordList = new List<string>();

        public EditorTextBox()
        {
            ShortcutsEnabled = false;
            DetectUrls = false;
            AutoWordSelection = true;
            WordWrap = false;
            Font = new Font("Courier New", 9.75f);

            keywordList.AddRange(new string[] {
                "abstract", "event", "new", "struct", "as", "explicit", "null",
                "switch", "base", "extern", "object", "this", "bool", "false",
                "operator", "throw", "break", "finally", "out", "true", "byte",
                "fixed", "override", "try", "case", "float", "params", "typeof",
                "catch", "for", "private", "uint", "char", "foreach", "protected",
                "ulong", "checked", "goto", "public", "unchecked", "class", "if",
                "readonly", "unsafe", "const", "implicit", "ref", "ushort", "continue",
                "in", "return", "using", "decimal", "int", "sbyte", "virtual",
                "default", "interface", "sealed", "volatile", "delegate", "internal",
                "short", "void", "do", "is", "sizeof", "while", "double", "lock",
                "stackalloc", "else", "long", "static", "enum", "namespace", "string" });
        }

        public override bool PreProcessMessage(ref Message msg)
        {
            if (msg.Msg == WM_KEYDOWN)
            {
                if (Control.ModifierKeys == Keys.Control)
                {
                    if (msg.WParam == (IntPtr)Keys.V)
                    {
                        Paste();
                        return true;
                    }
                    else if (msg.WParam == (IntPtr)Keys.C)
                    {
                        Copy();
                        return true;
                    }
                    else if (msg.WParam == (IntPtr)Keys.X)
                    {
                        Cut();
                        return true;
                    }
                }
                else if (Control.ModifierKeys == Keys.None)
                {
                    if (msg.WParam == (IntPtr)Keys.Tab)
                    {
                        SelectedText = "    ";
                    }
                }
            }

            return base.PreProcessMessage(ref msg);
        }

        public new virtual void Paste()
        {
            string text = Clipboard.GetText();
            if (text != null)
            {
                int selStart = SelectionStart;
                SelectedText = text;
                ReformatText();
            }
        }

        protected override void OnTextChanged(EventArgs e)
        {
            base.OnTextChanged(e);

            int line = GetLineFromCharIndex(SelectionStart);

            if (line < Lines.Length)
                ReformatText(GetFirstCharIndexOfCurrentLine(), Lines[line].Length);
        }

        public void ReformatText()
        {
            ReformatText(0, TextLength);
        }

        protected virtual void ReformatText(int startIndex, int lenght)
        {
            if (startIndex < 0 || lenght == 0)
                return;

            LockWindowUpdate();

            State state = GetState();

            string text = Text;

            while (startIndex > 0 && Char.IsLetterOrDigit(text[startIndex]))
            {
                startIndex--;
                lenght++;
            }

            lenght = Math.Min(lenght, text.Length - startIndex);

            string formattedText = text.Substring(startIndex, lenght);

            ResetColors(startIndex, lenght);

            for (int i = 0; i < keywordList.Count; i++)
            {
                string word = keywordList[i];
                int[] indicies = FindWordIndexes(formattedText, word);

                for (int a = 0; a < indicies.Length; a++)
                {
                    SetColor(startIndex + indicies[a], word.Length, System.Drawing.Color.Blue);
                }
            }

            SetState(state);

            UnlockWindowUpdate();
        }

        private int[] FindWordIndexes(string text, string word)
        {
            List<int> indexes = new List<int>();

            int offset = 0;
            int index = -1;

            do
            {
                index = text.IndexOf(word, offset);

                if (index >= 0)
                {
                    if (index == 0 ||
                        !Char.IsLetterOrDigit(text[index - 1]) &&
                        (index + word.Length == text.Length || !Char.IsLetterOrDigit(text[index + word.Length])))
                    {
                        indexes.Add(index);
                    }

                    offset = index + word.Length;
                }
            }
            while (index >= 0);

            return indexes.ToArray();
        }
    }
}
