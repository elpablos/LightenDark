using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Phoenix.Gui.Editor
{
    public partial class EditorDialog : Form
    {
        private FileInfo file;

        public EditorDialog(FileInfo file)
        {
            if (file == null)
                throw new ArgumentNullException("file");

            InitializeComponent();

            this.file = file;

            editorTextBox.LoadFile(file.FullName, RichTextBoxStreamType.PlainText);
            editorTextBox.ReformatText();
            editorTextBox.Modified = false;
            ResetTitle();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            editorTextBox.SaveFile(file.FullName, RichTextBoxStreamType.PlainText);
            editorTextBox.Modified = false;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            editorTextBox.Undo();
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            editorTextBox.Redo();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            editorTextBox.Cut();
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            editorTextBox.Copy();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            editorTextBox.Paste();
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            editorTextBox.SelectAll();
        }

        private void EditorDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (editorTextBox.Modified)
            {
                DialogResult result = MessageBox.Show("File modified. Save?", file.Name, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                switch (result)
                {
                    case DialogResult.Yes:
                        editorTextBox.SaveFile(file.FullName, RichTextBoxStreamType.PlainText);
                        break;

                    case DialogResult.No:
                        break;

                    case DialogResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
        }

        private void editorTextBox_ModifiedChanged(object sender, EventArgs e)
        {
            ResetTitle();
        }

        private void ResetTitle()
        {
            Text = String.Format("Script Editor - {0}{1}", file.Name, editorTextBox.Modified ? "*" : "");
        }
    }
}