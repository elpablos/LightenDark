using System;
using System.Collections.Generic;
using System.Text;

namespace Phoenix.Gui
{
    public enum WindowTaskbarConfig
    {
        ShowInTaskbar,
        ShowInTray,
        MinimazeToTray
    }
}
