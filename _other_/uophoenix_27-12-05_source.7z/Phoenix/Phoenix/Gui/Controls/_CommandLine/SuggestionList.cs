using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Phoenix.Gui.Controls._CommandLine
{
    internal sealed partial class SuggestionList : Form
    {
        private CommandLineBox parent;
        private string[] wordList;
        private string filter;

        public SuggestionList(CommandLineBox parent)
        {
            if (parent == null)
                throw new ArgumentNullException("parent");

            InitializeComponent();

            this.parent = parent;
            wordList = new string[0];
            filter = "";
        }

        public string[] WordList
        {
            get { return wordList; }
            set
            {
                if (value != null)
                {
                    wordList = value;
                    UpdateList(false);
                }
            }
        }

        public string Filter
        {
            get { return filter; }
            set
            {
                if (value != null && value != filter)
                {
                    filter = value;
                    UpdateList(true);
                }
            }
        }

        private void UpdateList(bool preserveSelected)
        {
            string selectedItem = null;
            if (preserveSelected)
                selectedItem = (string)listBox.SelectedItem;

            listBox.Items.Clear();

            foreach (string word in wordList)
            {
                if (word.StartsWith(filter, StringComparison.InvariantCultureIgnoreCase))
                {
                    listBox.Items.Add(word);
                }
            }

            if (preserveSelected)
            {
                listBox.SelectedItem = selectedItem;
            }

            if (listBox.Items.Count == 0)
                Hide();
            else if (preserveSelected)
                Show();
        }

        protected override void OnLostFocus(EventArgs e)
        {
            Hide();
            base.OnLostFocus(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            parent.ExternalKeyDown(e);
        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            parent.ExternalKeyPress(e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            parent.ExternalKeyUp(e);
        }
    }
}