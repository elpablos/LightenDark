using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Phoenix.Runtime;
using Phoenix.Gui.Controls._CommandLine;

namespace Phoenix.Gui.Controls
{
    [ToolboxBitmap(typeof(TextBox))]
    public partial class CommandLineBox : UserControl
    {
        private SuggestionList suggestionList;

        public CommandLineBox()
        {
            InitializeComponent();

            suggestionList = new SuggestionList(this);

            suggestionList.WordList = new string[] { "exec", "run", "bandageself" };
        }

        [Browsable(true)]
        [DefaultValue("")]
        public virtual new string Text
        {
            get { return commandBox.Text.Replace("\r", ""); }
            set { commandBox.Text = value; }
        }

        [Browsable(true)]
        [DefaultValue(false)]
        public bool Multiline
        {
            get { return commandBox.Multiline; }
            set
            {
                commandBox.Multiline = value;
                commandBox.ScrollBars = value ? RichTextBoxScrollBars.Both : RichTextBoxScrollBars.None;

                string text = commandBox.Text;
                if (!value && text.Contains("\n"))
                {
                    commandBox.Text = text.Remove(text.IndexOf('\n')).Replace("\r", "");
                }
            }
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            commandBox.SelectedText = e.KeyChar.ToString();

            string line = commandBox.Lines[commandBox.GetLineFromCharIndex(commandBox.SelectionStart)];

            suggestionList.Filter = line;
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);
        }

        private void moreButton_Click(object sender, EventArgs e)
        {
        }

        internal void ExternalKeyDown(KeyEventArgs e)
        {
            OnKeyDown(e);
        }

        internal void ExternalKeyPress(KeyPressEventArgs e)
        {
            OnKeyPress(e);
        }

        internal void ExternalKeyUp(KeyEventArgs e)
        {
            OnKeyUp(e);
        }
    }
}
