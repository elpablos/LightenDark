using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Phoenix.Gui.Controls
{
    public class KeyBox : TextBox
    {
        private const int WM_KEYDOWN = 0x0100;
        private const int WM_SYSKEYDOWN = 0x0104;
        private const int WM_SYSDEADCHAR = 0x0107;

        private Keys key;

        [Browsable(true)]
        [Category("Property Changed")]
        public event EventHandler KeyChanged;

        public KeyBox()
        {
            ReadOnly = true;
            BackColor = SystemColors.Window;
            WordWrap = false;
            MaxLength = 64;

            Key = Keys.None;
        }

        [Browsable(false)]
        [DefaultValue(false)]
        public override bool Multiline
        {
            get { return false; }
            set { }
        }

        [Browsable(false)]
        [DefaultValue(false)]
        public override bool ShortcutsEnabled
        {
            get { return false; }
            set { }
        }

        [Browsable(true)]
        [Category("Appearance")]
        [DefaultValue("None")]
        public Keys Key
        {
            get { return key; }
            set
            {
                if (value != key)
                {
                    key = value;
                    Text = value.ToString();
                    OnKeyChanged(EventArgs.Empty);
                }
            }
        }

        protected virtual void OnKeyChanged(EventArgs e)
        {
            SyncEvent.Invoke(KeyChanged, this, e);
        }

        public override bool PreProcessMessage(ref Message msg)
        {
            return false;
        }

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case WM_KEYDOWN:
                case WM_SYSKEYDOWN:
                case WM_SYSDEADCHAR:
                    Keys keyCode = (Keys)m.WParam;

                    if (keyCode != Keys.ControlKey && keyCode != Keys.ShiftKey && keyCode != Keys.Menu)
                    {
                        Key = keyCode | Control.ModifierKeys;
                    }

                    m.Result = IntPtr.Zero;
                    return;

                default:
                    base.WndProc(ref m);
                    return;
            }
        }
    }
}
