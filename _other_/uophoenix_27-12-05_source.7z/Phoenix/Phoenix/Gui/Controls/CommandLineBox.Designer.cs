namespace Phoenix.Gui.Controls
{
    partial class CommandLineBox
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.commandBox = new System.Windows.Forms.RichTextBox();
            this.moreButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // commandBox
            // 
            this.commandBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.commandBox.AutoWordSelection = true;
            this.commandBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.commandBox.DetectUrls = false;
            this.commandBox.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.commandBox.Location = new System.Drawing.Point(0, 0);
            this.commandBox.Multiline = false;
            this.commandBox.Name = "commandBox";
            this.commandBox.RichTextShortcutsEnabled = false;
            this.commandBox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.commandBox.Size = new System.Drawing.Size(182, 21);
            this.commandBox.TabIndex = 0;
            this.commandBox.Text = "";
            this.commandBox.WordWrap = false;
            // 
            // moreButton
            // 
            this.moreButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.moreButton.Enabled = false;
            this.moreButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.moreButton.Location = new System.Drawing.Point(180, 0);
            this.moreButton.Name = "moreButton";
            this.moreButton.Size = new System.Drawing.Size(18, 21);
            this.moreButton.TabIndex = 1;
            this.moreButton.Text = ">";
            this.moreButton.Click += new System.EventHandler(this.moreButton_Click);
            // 
            // CommandLineBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.moreButton);
            this.Controls.Add(this.commandBox);
            this.Name = "CommandLineBox";
            this.Size = new System.Drawing.Size(198, 21);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox commandBox;
        private System.Windows.Forms.Button moreButton;
    }
}
