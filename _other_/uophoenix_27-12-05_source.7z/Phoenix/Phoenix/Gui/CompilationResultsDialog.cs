using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Phoenix.Editor.Controls;

namespace Phoenix.Gui
{
    public partial class CompilationResultsDialog : Form
    {
        private readonly Size smallSize = new Size(241, 113);
        private Size largeSize = new Size(600, 360);
        private bool expanded = false;

        public CompilationResultsDialog()
        {
            InitializeComponent();

            this.Size = smallSize;
            moreButton.Text = "More >>";
            PerformControlsLayout();
        }

        public CompilationResults Results
        {
            get { return compilatonResults; }
        }

        public string Message
        {
            get { return messageBox.Text; }
            set { messageBox.Text = value; }
        }

        public bool Expanded
        {
            get { return expanded; }
        }

        public void Toggle()
        {
            SuspendLayout();
            if (expanded)
            {
                expanded = false;
                largeSize = this.Size;
                this.FormBorderStyle = FormBorderStyle.FixedDialog;
                this.MaximizeBox = false;
                compilatonResults.Visible = false;
                this.WindowState = FormWindowState.Normal;
                this.Size = smallSize;
                moreButton.Text = "More >>";
            }
            else
            {
                compilatonResults.Visible = true;
                this.Size = largeSize;
                this.FormBorderStyle = FormBorderStyle.Sizable;
                this.MaximizeBox = true;
                moreButton.Text = "<< Less";
                expanded = true;
            }
            PerformControlsLayout();
            ResumeLayout();
        }

        private void PerformControlsLayout()
        {
            SuspendLayout();

            // closeButton.Location = new Point(ClientSize.Width / 2 - 3 - closeButton.Width, 50);
            // moreButton.Location = new Point(ClientSize.Width / 2 + 3, 50);

            if (expanded)
            {
                int y = closeButton.Bottom + 6;
                compilatonResults.Location = new Point(0, y);
                compilatonResults.Width = ClientSize.Width;
                compilatonResults.Height = ClientSize.Height - y;
            }

            ResumeLayout();
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);

            PerformControlsLayout();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void moreButton_Click(object sender, EventArgs e)
        {
            Toggle();
        }
    }
}