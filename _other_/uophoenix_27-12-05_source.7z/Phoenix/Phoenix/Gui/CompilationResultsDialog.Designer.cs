namespace Phoenix.Gui
{
    partial class CompilationResultsDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CompilationResultsDialog));
            this.moreButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.iconBox = new Phoenix.Gui.Controls.IconBox();
            this.compilatonResults = new Phoenix.Editor.Controls.CompilationResults();
            this.messageBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // moreButton
            // 
            this.moreButton.Location = new System.Drawing.Point(135, 50);
            this.moreButton.Name = "moreButton";
            this.moreButton.Size = new System.Drawing.Size(75, 23);
            this.moreButton.TabIndex = 4;
            this.moreButton.Text = "More >>";
            this.moreButton.Click += new System.EventHandler(this.moreButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(54, 50);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 5;
            this.closeButton.Text = "Close";
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // iconBox
            // 
            this.iconBox.BackColor = System.Drawing.Color.Transparent;
            this.iconBox.BackgroundImage = null;
            this.iconBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.iconBox.ForeColor = System.Drawing.Color.Transparent;
            this.iconBox.Icon = ((System.Drawing.Icon)(resources.GetObject("iconBox.Icon")));
            this.iconBox.Location = new System.Drawing.Point(12, 12);
            this.iconBox.Name = "iconBox";
            this.iconBox.Size = new System.Drawing.Size(32, 32);
            this.iconBox.TabIndex = 2;
            this.iconBox.Text = "IconBox";
            // 
            // compilatonResults
            // 
            this.compilatonResults.CompilerOutput = null;
            this.compilatonResults.Location = new System.Drawing.Point(9, 77);
            this.compilatonResults.Margin = new System.Windows.Forms.Padding(0);
            this.compilatonResults.Name = "compilatonResults";
            this.compilatonResults.Size = new System.Drawing.Size(217, 166);
            this.compilatonResults.TabIndex = 1;
            this.compilatonResults.Visible = false;
            // 
            // messageBox
            // 
            this.messageBox.BackColor = System.Drawing.SystemColors.Control;
            this.messageBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.messageBox.Location = new System.Drawing.Point(54, 12);
            this.messageBox.Multiline = true;
            this.messageBox.Name = "messageBox";
            this.messageBox.Size = new System.Drawing.Size(169, 32);
            this.messageBox.TabIndex = 6;
            this.messageBox.Text = "message";
            // 
            // CompilationResultsDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(235, 250);
            this.Controls.Add(this.messageBox);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.moreButton);
            this.Controls.Add(this.iconBox);
            this.Controls.Add(this.compilatonResults);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CompilationResultsDialog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Copilation Results";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Phoenix.Gui.Controls.IconBox iconBox;
        private System.Windows.Forms.Button moreButton;
        private System.Windows.Forms.Button closeButton;
        private Phoenix.Editor.Controls.CompilationResults compilatonResults;
        private System.Windows.Forms.TextBox messageBox;
    }
}