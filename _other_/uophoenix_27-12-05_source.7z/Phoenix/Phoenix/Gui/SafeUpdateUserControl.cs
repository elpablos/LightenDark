using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Reflection;

namespace Phoenix.Gui
{
    public struct UpdateContentsMessage
    {
        private int msg;
        private object[] parameters;

        public UpdateContentsMessage(int msg)
        {
            this.msg = msg;
            this.parameters = new object[0];
        }

        public UpdateContentsMessage(int msg, params object[] parameters)
        {
            this.msg = msg;
            this.parameters = parameters;
        }

        public int Msg
        {
            get { return msg; }
        }

        public object FirstParam
        {
            get { return parameters[0]; }
        }

        public object[] Parameters
        {
            get { return parameters; }
        }
    }

    [ToolboxItem(false)]
    public class SafeUpdateUserControlUNUSED : UserControl
    {
        private const int WM_APP = 0x8000;
        protected const int WM_UPDATECONTENTS = (WM_APP + 1);
        protected const int UC_SETPROPERTY = 0xF001;
        protected const int UC_SETTEXT = 0xF002;

        [DllImport("user32.dll")]
        protected static extern bool PostMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        private IntPtr safeHandle = IntPtr.Zero;
        private readonly object syncRoot = new object();
        private Queue<UpdateContentsMessage> messageQueue = new Queue<UpdateContentsMessage>();

        public SafeUpdateUserControlUNUSED()
        {
        }

        public virtual IntPtr SafeHandle
        {
            get
            {
                if (safeHandle == IntPtr.Zero)
                    throw new InvalidOperationException("Handle not created yet.");
                else
                    return safeHandle;
            }
        }

        public virtual bool IsSafeHandleCreated
        {
            get { return safeHandle != IntPtr.Zero; }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            safeHandle = Handle;
            base.OnHandleCreated(e);

            PostMessage(SafeHandle, WM_UPDATECONTENTS, 0, 0);
        }

        protected override void OnHandleDestroyed(EventArgs e)
        {
            safeHandle = IntPtr.Zero;
            base.OnHandleDestroyed(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_UPDATECONTENTS)
            {
                lock (syncRoot)
                {
                    while (messageQueue.Count > 0)
                    {
                        OnUpdateContents(messageQueue.Dequeue());
                    }
                }

                m.Result = IntPtr.Zero;
            }
            else
            {
                base.WndProc(ref m);
            }
        }

        protected virtual void OnUpdateContents(UpdateContentsMessage m)
        {
            switch (m.Msg)
            {
                case UC_SETPROPERTY:
                    Trace.Assert(m.Parameters.Length == 3, "Invalid number of parameters in UC_SETPROPERTY message.");

                    Trace.Assert(m.Parameters[0] != null, "Invalid object in UC_SETPROPERTY message.");
                    Trace.Assert(m.Parameters[1] != null, "Invalid property name in UC_SETPROPERTY message.");

                    string name = m.Parameters[1].ToString();
                    PropertyInfo pi = m.Parameters[0].GetType().GetProperty(name, BindingFlags.Instance | BindingFlags.Public);

                    Trace.Assert(pi != null, "Property of specified name not found.");

                    try
                    {
                        pi.SetValue(m.Parameters[0], m.Parameters[2], new object[0]);
                    }
                    catch (Exception e)
                    {
                        Trace.Fail("Unable to set property.", e.ToString());
                    }
                    return;

                case UC_SETTEXT:
                    Trace.Assert(m.Parameters.Length == 2, "Invalid number of parameters in UC_SETTEXT message.");

                    Control c = m.Parameters[0] as Control;

                    Trace.Assert(c != null, "Invalid control in UC_SETTEXT message.");
                    Trace.Assert(m.Parameters[1] != null, "Invalid text in UC_SETTEXT message.");

                    if (c != null)
                    {
                        c.Text = m.Parameters[1].ToString();
                    }
                    return;
            }
        }

        protected void RequestUpdate(int msg)
        {
            RequestUpdate(new UpdateContentsMessage(msg));
        }

        protected void RequestUpdate(int msg, params object[] parameters)
        {
            RequestUpdate(new UpdateContentsMessage(msg, parameters));
        }

        protected void RequestUpdate(UpdateContentsMessage m)
        {
            lock (syncRoot)
            {
                messageQueue.Enqueue(m);

                if (IsSafeHandleCreated)
                {
                    PostMessage(SafeHandle, WM_UPDATECONTENTS, 0, 0);
                }
            }
        }

        protected void SetControlPropertySafe(Control control, string propery, object value)
        {
            RequestUpdate(UC_SETPROPERTY, control, propery, value);
        }

        protected void SetControlTextSafe(Control control, string format, params object[] args)
        {
            SetControlTextSafe(control, String.Format(format, args));
        }

        protected void SetControlTextSafe(Control control, string text)
        {
            if (control == null)
                throw new ArgumentNullException("control");

            if (text == null)
                throw new ArgumentNullException("text");

            RequestUpdate(UC_SETTEXT, control, text);
        }
    }
}
