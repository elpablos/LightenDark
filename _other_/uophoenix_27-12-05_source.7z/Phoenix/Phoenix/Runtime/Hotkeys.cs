using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using Phoenix.Configuration;

namespace Phoenix.Runtime
{
    public class HotkeyShortcutChangedEventArgs : EventArgs
    {
        private Keys shortcut;

        public HotkeyShortcutChangedEventArgs(Keys shortcut)
        {
            this.shortcut = shortcut;
        }

        public Keys Shortcut
        {
            get { return shortcut; }
        }
    }

    public delegate void HotkeyShortcutChangedEventHandler(object sender, HotkeyShortcutChangedEventArgs e);

    internal class HotkeyShortcutChangedPublicEvent : PublicEvent<HotkeyShortcutChangedEventHandler, HotkeyShortcutChangedEventArgs>
    {
    }

    public class Hotkeys
    {
        #region CommandList class

        private class CommandList
        {
            private string text;
            private TextCommand[] list;

            public CommandList(string text)
            {
                string cmdLine = "";

                string[] commands = text.Replace("\r", "").Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                List<TextCommand> commandList = new List<TextCommand>(commands.Length);

                foreach (string command in commands)
                {
                    if (command.Length > 0)
                    {
                        cmdLine += command + "\n";
                        commandList.Add(TextCommand.Parse(command));
                    }
                }

                if (cmdLine.Contains("\n"))
                    cmdLine = cmdLine.Remove(cmdLine.LastIndexOf('\n'));

                list = commandList.ToArray();
                this.text = cmdLine;
            }

            public string Text
            {
                get { return text; }
            }

            public TextCommand[] List
            {
                get { return list; }
            }

            internal void Run()
            {
                foreach (TextCommand cmd in list)
                {
                    RuntimeCore.Executions.Run(RuntimeCore.CommandList[cmd.Command], cmd.Arguments);
                }
            }
        }

        #endregion

        private readonly object syncRoot;
        private Dictionary<Keys, CommandList> hotkeys;
        private HotkeyShortcutChangedPublicEvent added;
        private HotkeyShortcutChangedPublicEvent removed;
        private HotkeyShortcutChangedPublicEvent updated;
        private DefaultPublicEvent cleared;

        public Hotkeys()
        {
            syncRoot = new object();
            hotkeys = new Dictionary<Keys, CommandList>();

            added = new HotkeyShortcutChangedPublicEvent();
            removed = new HotkeyShortcutChangedPublicEvent();
            updated = new HotkeyShortcutChangedPublicEvent();
            cleared = new DefaultPublicEvent();
        }

        internal void Init()
        {
            Config.Profile.Settings.Loaded += new EventHandler(Settings_Loaded);
            Config.Profile.Settings.Saving += new EventHandler(Settings_Saving);
        }

        public event HotkeyShortcutChangedEventHandler Added
        {
            add { added.AddHandler(value); }
            remove { added.RemoveHandler(value); }
        }

        public event HotkeyShortcutChangedEventHandler Removed
        {
            add { removed.AddHandler(value); }
            remove { removed.RemoveHandler(value); }
        }

        public event HotkeyShortcutChangedEventHandler Updated
        {
            add { updated.AddHandler(value); }
            remove { updated.RemoveHandler(value); }
        }

        public event EventHandler Cleared
        {
            add { cleared.AddHandler(value); }
            remove { cleared.RemoveHandler(value); }
        }

        void Settings_Loaded(object sender, EventArgs e)
        {
            Reload();
        }

        internal void Reload()
        {
            lock (syncRoot)
            {
                hotkeys.Clear();
                cleared.Invoke(this, EventArgs.Empty);

                ElementInfo[] elements = Config.Profile.Settings.EnumarateElements("Hotkeys", "Hotkey");

                foreach (ElementInfo ei in elements)
                {
                    try
                    {
                        if (ei.Value != null)
                        {
                            Keys shortcut = (Keys)Enum.Parse(typeof(Keys), ei.Attributes["shortcut"].ToString(), true);
                            Add(shortcut, ei.Value);
                        }
                    }
                    catch (Exception e)
                    {
                        Trace.WriteLine("Error reading hotkey from config. Message: " + e.Message, "Hotkeys");
                    }
                }

                Debug.WriteLine("Reloaded.", "Hotkeys");
            }
        }

        void Settings_Saving(object sender, EventArgs e)
        {
            lock (syncRoot)
            {
                Config.Profile.Settings.RemoveElement("Hotkeys");

                foreach (KeyValuePair<Keys, CommandList> pair in hotkeys)
                {
                    Config.Profile.Settings.SetElement(pair.Value.Text, "Hotkeys", new ElementInfo("Hotkey", new AttributeInfo("shortcut", pair.Key)));
                }
            }
        }

        public bool Contains(Keys shortcut)
        {
            lock (syncRoot)
            {
                return hotkeys.ContainsKey(shortcut);
            }
        }

        public string Get(Keys shortcut)
        {
            lock (syncRoot)
            {
                if (!hotkeys.ContainsKey(shortcut))
                    throw new Exception("Hotkey doesn't exist.");

                return hotkeys[shortcut].Text;
            }
        }

        /// <param name="commands">Multiple commands can be separated by '\n'.</param>
        public void Update(Keys shortcut, string commands)
        {
            if (commands == null)
                throw new ArgumentNullException("commands");

            lock (syncRoot)
            {
                if (!hotkeys.ContainsKey(shortcut))
                    throw new Exception("Hotkey doesn't exist.");

                hotkeys[shortcut] = new CommandList(commands);
            }

            updated.Invoke(this, new HotkeyShortcutChangedEventArgs(shortcut));
        }

        /// <param name="commands">Multiple commands can be separated by '\n'.</param>
        public void Add(Keys shortcut, string commands)
        {
            if (shortcut == Keys.None)
                throw new ArgumentException("No shortcut specified.", "shortcut");

            if (commands == null)
                throw new ArgumentNullException("commands");

            lock (syncRoot)
            {
                if (hotkeys.ContainsKey(shortcut))
                    throw new Exception("Hotkey already exists.");

                hotkeys.Add(shortcut, new CommandList(commands));
            }

            added.Invoke(this, new HotkeyShortcutChangedEventArgs(shortcut));
        }

        public void Remove(Keys shortcut)
        {
            lock (syncRoot)
            {
                if (!hotkeys.ContainsKey(shortcut))
                    throw new Exception("Hotkey doesn't exist.");

                hotkeys.Remove(shortcut);
            }

            removed.Invoke(this, new HotkeyShortcutChangedEventArgs(shortcut));
        }

        public void Run(Keys shortcut)
        {
            CommandList cmdList;

            lock (syncRoot)
            {
                hotkeys.TryGetValue(shortcut, out cmdList);
            }

            if (cmdList != null)
            {
                cmdList.Run();
            }
            else
            {
                throw new RuntimeException("Hotkey " + shortcut.ToString() + " not found.");
            }
        }

        [Command("hotkey")]
        public void Exec(Keys shortcut)
        {
            lock (syncRoot)
            {
                CommandList cmdList;

                if (hotkeys.TryGetValue(shortcut, out cmdList))
                {
                    ThreadStarter.StartBackround(new WorkerDelegate(Worker), shortcut, cmdList);
                }
                else
                {
                    UO.PrintError("Hotkey {0} not found.", shortcut);
                }
            }
        }

        private delegate void WorkerDelegate(Keys shortcut, CommandList cmdList);
        private static void Worker(Keys shortcut, CommandList cmdList)
        {
            try
            {
                Debug.WriteLine("Hotkey execution " + shortcut.ToString() + " started.", "Runtime");

                cmdList.Run();
            }
            catch (ThreadAbortException)
            {
                UO.PrintInformation("Hotkey {0} execution terminated.", shortcut);
            }
            catch (ScriptErrorException e)
            {
                Trace.WriteLine("Unhandled exception:\n" + e.ToString(), "Script");
                UO.PrintError(e.Message);
            }
            catch (Exception e)
            {
                Trace.WriteLine("Unhandled error during hotkey execution. Exception:" + Environment.NewLine + e.ToString(), "Runtime");
                UO.PrintError("Hotkey error: {0}", e.Message);
            }
            finally
            {
                Debug.WriteLine("Hotkey execution " + shortcut.ToString() + " finished.", "Runtime");
            }
        }
    }
}
