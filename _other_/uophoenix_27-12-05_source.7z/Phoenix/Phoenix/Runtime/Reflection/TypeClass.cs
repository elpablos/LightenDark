using System;
using System.Collections.Generic;
using System.Text;

namespace Phoenix.Runtime.Reflection
{
    public enum TypeClass
    {
        Number,
        Object
    }
}
