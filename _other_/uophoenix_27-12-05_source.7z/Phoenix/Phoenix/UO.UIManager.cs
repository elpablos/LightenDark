using System;
using System.Collections.Generic;
using System.Text;
using Phoenix.WorldData;

namespace Phoenix
{
    public partial class UO
    {
        [Command]
        public static void WaitTargetObject(Serial serial)
        {
            if (serial.IsValid)
                UIManager.WaitForTarget(serial, 0, 0, 0, 0);
            else
                ScriptErrorException.Throw("Invalid serial specified to WaitTargetObject.");
        }

        [Command]
        public static void WaitTargetSelf()
        {
            UIManager.WaitForTarget(World.PlayerSerial, 0, 0, 0, 0);
        }

        [Command]
        public static void WaitTargetLast()
        {
            WaitTargetObject(Aliases.LastTarget);
        }

        [Command]
        public static void WaitTargetCancel()
        {
            UIManager.WaitForTarget(0, 0xFFFF, 0xFFFF, 0, 0);
        }

        [Command]
        public static void WaitMenu(params string[] menus)
        {
            if (menus.Length != 0 && menus.Length % 2 == 0)
            {
                MenuSelection[] menuList = new MenuSelection[menus.Length / 2];

                for (int i = 0; i < menuList.Length; i++)
                {
                    menuList[i] = new MenuSelection(menus[i * 2], menus[i * 2 + 1]);
                }

                UIManager.WaitForMenu(menuList);
            }
            else
            {
                ScriptErrorException.Throw("Invalid number of parameters.");
            }
        }

        [Command]
        public static void WaitTargetType(Graphic graphic)
        {
            WaitTargetType(graphic, UOColor.Invariant);
        }

        [Command]
        public static void WaitTargetType(Graphic graphic, UOColor color)
        {
            UOItem item = World.Player.Backpack.AllItems.FindType(graphic, color);

            if (item.Exist)
                WaitTargetObject(item);
            else
                ScriptErrorException.Throw("Type not found.");
        }
    }
}
