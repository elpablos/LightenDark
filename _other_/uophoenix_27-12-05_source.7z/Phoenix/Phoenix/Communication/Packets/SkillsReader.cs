using System;
using System.Collections.Generic;
using System.Text;

namespace Phoenix.Communication.Packets
{
    public struct SkillValue
    {
        public ushort ID;
        public ushort Value;
        public ushort RealValue;
        public byte Lock;

        public SkillValue(ushort id, ushort value, ushort realValue, byte lockStatus)
        {
            ID = id;
            Value = value;
            RealValue = realValue;
            Lock = lockStatus;
        }

        public bool Valid
        {
            get { return ID != 0xFFFF; }
        }

        public static SkillValue Invalid
        {
            get { return new SkillValue(0xFFFF, 0, 0, 0); }
        }
    }

    public class SkillsReader : VariablePacket
    {
        private Dictionary<int, SkillValue> list;

        public SkillsReader(byte[] data)
            : base(data)
        {
            list = new Dictionary<int, SkillValue>();

            PacketReader reader = new PacketReader(data);
            reader.Skip(3);

            byte listType = reader.ReadByte();

            while (reader.Offset < reader.Length && reader.Offset < Lenght)
            {
                SkillValue value = new SkillValue();
                value.ID = reader.ReadUInt16();
                value.Value = reader.ReadUInt16();
                value.RealValue = reader.ReadUInt16();
                value.Lock = reader.ReadByte();
                list.Add(value.ID, value);
            }
        }

        public override byte Id
        {
            get { return 0x3A; }
        }

        public SkillValue this[int id]
        {
            get
            {
                SkillValue value;
                if (list.TryGetValue(id, out value))
                    return value;
                else
                    return SkillValue.Invalid;
            }
        }
        }
    }
