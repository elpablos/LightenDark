using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Phoenix.Communication
{
    class ActionSpamLimiter
    {
        private int limit;
        private Timer timer;
        private int count;
        private string message;

        public ActionSpamLimiter(int limit, int refresh, string message)
        {
            this.limit = limit;
            this.message = message;
            timer = new Timer(new TimerCallback(TimerCallback), null, 1000, refresh);
        }

        public int Limit
        {
            get { return limit; }
        }

        public string Message
        {
            get { return message; }
            set { message = value; }
        }

        private void TimerCallback(object state)
        {
            if (count > 0) count--;
        }

        public bool OnMessage(byte[] data)
        {
            if (count > limit)
            {
                System.Diagnostics.Trace.WriteLine(String.Format("Action spam detected. Packet 0x{0:X2} dropped.", data[0]), "Communication");

                if (message != null)
                {
                    UO.PrintWarning(message);
                }

                return true;
            }
            else
            {
                count++;
                return false;
            }
        }
    }
}
