using System;
using System.Collections.Generic;
using System.Text;
using Phoenix.Communication;

namespace Phoenix
{
    public class TargetInfo
    {
        internal byte Type;
        internal uint TargetId;
        internal byte Flags;
        public uint Serial;
        public ushort X;
        public ushort Y;
        public sbyte Z;
        public ushort Graphic;

        internal byte[] ToData()
        {
            return PacketBuilder.Target(Type, TargetId, Flags, Serial, X, Y, Z, Graphic);
        }

        internal static TargetInfo FromData(byte[] data)
        {
            if (data[0] != 0x6C) throw new ArgumentException("Invalid packet.");

            TargetInfo info = new TargetInfo();
            info.Type = data[1];
            info.TargetId = ByteConverter.LittleEndian.ToUInt32(data, 2);
            info.Flags = data[6];
            info.Serial = ByteConverter.LittleEndian.ToUInt32(data, 7);
            info.X = ByteConverter.LittleEndian.ToUInt16(data, 11);
            info.Y = ByteConverter.LittleEndian.ToUInt16(data, 13);
            info.Z = ByteConverter.LittleEndian.ToSByte(data, 16);
            info.Graphic = ByteConverter.LittleEndian.ToUInt16(data, 17);

            return info;
        }
    }
}
