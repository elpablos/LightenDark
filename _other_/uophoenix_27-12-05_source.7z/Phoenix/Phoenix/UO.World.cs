using System;
using System.Collections.Generic;
using System.Text;
using Phoenix.WorldData;
using Phoenix.Communication;

namespace Phoenix
{
    partial class UO
    {
        private const int DefaultPause = 500;

        public static UOItem Backpack
        {
            get { return World.Player.Backpack; }
        }

        public static int Count(ushort type)
        {
            return World.Player.Backpack.AllItems.Count(type);
        }

        public static int Count(ushort type, ushort color)
        {
            return World.Player.Backpack.AllItems.Count(type, color);
        }

        [Command]
        public static void OpenDoor()
        {
            Core.SendToServer(PacketBuilder.OpenDoor());
        }

        [Command]
        public static void UseObject(Serial serial)
        {
            if (serial.IsValid)
                Core.SendToServer(PacketBuilder.ObjectDoubleClick(serial));
            else
                ScriptErrorException.Throw("Invalid serial specified to UseObject.");

            Aliases.LastObject = serial;
        }

        [Command]
        public static void ClickObject(Serial serial)
        {
            if (serial.IsValid)
                Core.SendToServer(PacketBuilder.ObjectClick(serial));
            else
                ScriptErrorException.Throw("Invalid serial specified to ClickObject.");
        }

        [Command]
        public static void UseType(Graphic graphic)
        {
            World.Player.Backpack.AllItems.FindType(graphic).Use();
        }

        [Command]
        public static void UseType(Graphic graphic, UOColor color)
        {
            World.Player.Backpack.AllItems.FindType(graphic, color).Use();
        }

        [Command]
        public static void SetReceivingContainer()
        {
            Aliases.RecevingContainer = UIManager.TargetObject();
        }

        [Command]
        public static void UnSetReceivingContainer()
        {
            Aliases.RecevingContainer = Serial.Invalid;
        }

        [Command]
        public static bool Grab()
        {
            return Grab(0);
        }

        [Command]
        public static bool Grab(ushort amount)
        {
            UO.Print("What item do you want to move?");
            return Grab(amount, UIManager.TargetObject());
        }

        [Command]
        public static bool Grab(ushort amount, Serial item)
        {
            return Grab(amount, item, Aliases.RecevingContainer);
        }

        [Command]
        public static bool Grab(ushort amount, Serial item, Serial recevingContainer)
        {
            if (!item.IsValid) {
                return ScriptErrorException.Throw("Invalid item serial.");
            }

            if (recevingContainer.IsValid) {
                return UIManager.MoveItem(item, amount, 0xFFFF, 0xFFFF, 0, recevingContainer);
            }
            else {
                return ScriptErrorException.Throw("Invalid RecevingContainer.");
            }
        }

        [Command]
        public static bool MoveItem(Serial item, ushort amount, Serial destination)
        {
            return MoveItem(item, amount, destination, 0xFFFF, 0xFFFF);
        }

        [Command]
        public static bool MoveItem(Serial item, ushort amount, Serial destination, ushort x, ushort y)
        {
            if (!item.IsValid)
                return ScriptErrorException.Throw("Invalid item serial.");

            if (!destination.IsValid)
                return ScriptErrorException.Throw("Destination container serial is invalid.");

            return UIManager.MoveItem(item, amount, x, y, 0, destination);
        }

        [Command]
        public static bool MoveItem(Serial item, ushort amount, ushort x, ushort y, sbyte z)
        {
            if (!item.IsValid)
                return ScriptErrorException.Throw("Invalid item serial.");

            return UIManager.MoveItem(item, amount, x, y, z, 0);
        }

        [Command("equip")]
        public static bool EquipItem()
        {
            UO.Print("What item do you want to equip?");
            return EquipItem(UIManager.TargetObject());
        }

        [Command("equip")]
        public static bool EquipItem(Serial serial)
        {
            if (!serial.IsValid)
                return ScriptErrorException.Throw("Item serial is invalid.");

            byte layer = 0;

            try {
                UOItem item = World.GetItem(serial);
                if (item.Exist)
                    layer = DataFiles.Tiledata.GetArt(item.Graphic).Layer;
            }
            catch (Exception e) {
                System.Diagnostics.Trace.WriteLine("Unexpected error in UO.EquipItem(). Exception:\n" + e.ToString(), "Runtime");
            }

            return UIManager.EquipItem(serial, World.Player.Serial, layer);
        }

        [Command]
        public static int EmptyContainer()
        {
            return EmptyContainer(DefaultPause, UIManager.TargetObject(), Aliases.RecevingContainer);
        }

        [Command]
        public static int EmptyContainer(int pause)
        {
            return EmptyContainer(pause, UIManager.TargetObject(), Aliases.RecevingContainer);
        }

        [Command]
        public static int EmptyContainer(int pause, Serial source)
        {
            return EmptyContainer(pause, source, Aliases.RecevingContainer);
        }

        [Command]
        public static int EmptyContainer(int pause, Serial source, Serial target)
        {
            pause = Math.Max(pause, 100);

            if (!source.IsValid) {
                ScriptErrorException.Throw("Source container serial is invalid.");
                return -1;
            }

            if (!target.IsValid) {
                ScriptErrorException.Throw("Target container serial is invalid.");
                return -1;
            }

            int movedCount = 0;
            foreach (UOItem item in World.GetItem(source).Items) {
                if (item.Move(0, target))
                    movedCount++;

                UO.Wait(pause);
            }

            return movedCount;
        }

        [Command]
        public static bool DropHere()
        {
            return Drop(0, 0, 0, 0, UIManager.TargetObject());
        }

        [Command]
        public static bool DropHere(ushort amount)
        {
            return Drop(amount, 0, 0, 0, UIManager.TargetObject());
        }

        [Command]
        public static bool DropHere(ushort amount, Serial item)
        {
            return Drop(amount, 0, 0, 0, item);
        }

        [Command]
        public static bool Drop(ushort amount, short relativeX, short relativeY, sbyte relativeZ)
        {
            return Drop(amount, relativeX, relativeY, relativeZ, UIManager.TargetObject());
        }

        [Command]
        public static bool Drop(ushort amount, short relativeX, short relativeY, sbyte relativeZ, Serial item)
        {
            return MoveItem(item, amount, (ushort)(World.Player.X + relativeX), (ushort)(World.Player.Y + relativeY), (sbyte)(World.Player.Z + relativeZ));
        }

        /// <summary>
        /// Requests status of character from server.
        /// </summary>
        /// <param name="serial">Character serial.</param>
        public static void RequestCharacterStatus(Serial serial)
        {
            if (!serial.IsValid)
                ScriptErrorException.Throw("Character serial is invalid.");

            Core.SendToServer(PacketBuilder.CharacterStatsRequest(serial, PacketBuilder.StatsRequestType.Stats));
        }

        /// <summary>
        /// Requests status of character from server.
        /// </summary>
        /// <param name="serial">Character serial.</param>
        /// <param name="timeout">Timeout period.</param>
        /// <returns>True when status update received; otherwise false.</returns>
        public static bool RequestCharacterStatus(Serial serial, int timeout)
        {
            if (!serial.IsValid)
                return ScriptErrorException.Throw("Character serial is invalid.");

            using (SpecializedObjectChangedEventWaiter ew = new SpecializedObjectChangedEventWaiter(serial, ObjectChangeType.CharUpdated)) {
                Core.SendToServer(PacketBuilder.CharacterStatsRequest(serial, PacketBuilder.StatsRequestType.Stats));
                return ew.Wait(timeout);
            }
        }
    }
}
