#if DEBUG
//#define WORLDDEBUG
#endif

using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Phoenix.Communication;
using Phoenix.Communication.Packets;

namespace Phoenix.WorldData
{
    internal static class WorldPacketHandler
    {
        internal static readonly ObjectCallbacksCollection ObjectCallbacks = new ObjectCallbacksCollection();
        internal static readonly CharacterAppearedPublicEvent characterAppeared = new CharacterAppearedPublicEvent();

        internal static void Init()
        {
            // Register handlers
            Core.RegisterServerMessageCallback(0x1A, new MessageCallback(OnItemDetails));
            Core.RegisterServerMessageCallback(0x1D, new MessageCallback(OnObjectRemove));
            Core.RegisterServerMessageCallback(0x24, new MessageCallback(OnOpenContainer));
            Core.RegisterServerMessageCallback(0x25, new MessageCallback(OnAddToContainer));
            Core.RegisterServerMessageCallback(0x3C, new MessageCallback(OnContainerContents));
            Core.RegisterServerMessageCallback(0x2E, new MessageCallback(OnCharacterAddItem));
            Core.RegisterServerMessageCallback(0x11, new MessageCallback(OnCharacterStatus));
            Core.RegisterServerMessageCallback(0x2D, new MessageCallback(OnUpdateStats));
            Core.RegisterServerMessageCallback(0xA1, new MessageCallback(OnUpdateHits));
            Core.RegisterServerMessageCallback(0xA2, new MessageCallback(OnUpdateMana));
            Core.RegisterServerMessageCallback(0xA3, new MessageCallback(OnUpdateStamina));
            Core.RegisterServerMessageCallback(0x1B, new MessageCallback(OnLoginConfirm), CallbackPriority.High);
            Core.RegisterServerMessageCallback(0x20, new MessageCallback(OnPlayerSync));
            Core.RegisterServerMessageCallback(0x77, new MessageCallback(OnCharacterUpdate));
            Core.RegisterServerMessageCallback(0x78, new MessageCallback(OnCharacterInformation));
            Core.RegisterServerMessageCallback(0x98, new MessageCallback(OnThingName));
            Core.RegisterServerMessageCallback(0x1C, new MessageCallback(OnAsciiSpeech));
            Core.RegisterServerMessageCallback(0xAE, new MessageCallback(OnUniSpeech));

            Core.Disconnected += new EventHandler(Core_Disconnected);

            WalkHandling.Init();
        }

        private static void ObjectChanged(uint serial, ObjectChangeType changeType)
        {
            ObjectCallbacks.InvokeAsync(new ObjectChangedEventArgs(serial, changeType));


            if (changeType == ObjectChangeType.ItemUpdated || changeType == ObjectChangeType.Removed)
            {
                ObjectChangeType subChange = (changeType == ObjectChangeType.Removed) ? ObjectChangeType.SubItemRemoved : ObjectChangeType.SubItemUpdated;

                RealItem item = World.FindRealItem(serial);
                if (item != null)
                {
                    do
                    {
                        RealObject obj = World.FindRealObject(item.Container);

                        if (obj != null)
                            ObjectCallbacks.InvokeAsync(new ObjectChangedEventArgs(obj.Serial, serial, subChange));

                        item = obj as RealItem;
                    }
                    while (item != null);
                }
            }
        }

        static void Core_Disconnected(object sender, EventArgs e)
        {
            World.Clear();
        }

        static CallbackResult OnItemDetails(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                PacketReader reader = new PacketReader(data);

                byte id = reader.ReadByte();
                if (id != 0x1A) throw new Exception("Invalid packet passed to OnItemDetails.");

                ushort blockSize = reader.ReadUInt16();

                if (blockSize != reader.Length)
                    return CallbackResult.Normal;

                uint serial = reader.ReadUInt32();

                RealItem item = World.FindRealItem(serial);
                if (item == null)
                {
                    item = new RealItem(serial);
                    World.Add(item);
                }

                ushort dispId = reader.ReadUInt16();

                if ((serial & 0x80000000) != 0)
                {
                    item.Amount = reader.ReadUInt16();
                }

                if ((dispId & 0x8000) != 0)
                {
                    dispId += reader.ReadByte();
                }

                item.Graphic = (ushort)(dispId & 0x7FFF);

                ushort x = reader.ReadUInt16();
                item.X = (ushort)(x & 0x7FFF);

                ushort y = reader.ReadUInt16();
                item.Y = (ushort)(y & 0x3FFF);

                if ((x & 0x8000) != 0)
                {
                    byte direction = reader.ReadByte();
                }

                item.Z = reader.ReadSByte();

                if ((y & 0x8000) != 0)
                {
                    item.Color = reader.ReadUInt16();
                }

                if ((y & 0x4000) != 0)
                {
                    item.Flags = reader.ReadByte();
                }

                item.Detach();

                ObjectChanged(serial, ObjectChangeType.ItemUpdated);

                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnObjectRemove(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0x1D) throw new Exception("Invalid packet passed to OnObjectRemove.");

                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 1);

                if (serial != World.PlayerSerial)
                {
                    World.Remove(serial);

                    Debug.WriteLine(String.Format("Object 0x{0} removed from world.", serial.ToString("X8")), "World");

                    ObjectCallbacks.InvokeAsync(new ObjectChangedEventArgs(serial, ObjectChangeType.Removed));
                    return CallbackResult.Normal;
                }
                else
                {
                    Debug.WriteLine("Cannot remove player. Packet dropped.", "World");
                    return CallbackResult.Eat;
                }
            }
        }

        static CallbackResult OnOpenContainer(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0x24) throw new Exception("Invalid packet passed to OnOpenContainer.");

                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 1);
                ushort gump = ByteConverter.LittleEndian.ToUInt16(data, 5);

                RealItem container = World.FindRealItem(serial);
                if (container == null)
                {
                    Debug.WriteLine("Cannot open non-existing container.", "World");
                    return CallbackResult.Normal;
                }

                // Items will be populated later.
                List<uint> removeList = new List<uint>();

                World.GetContainerContents(container.Serial, removeList);

                for (int i = 0; i < removeList.Count; i++)
                {
                    World.ItemList.Remove(removeList[i]);
                }

                container.Opened = true;

                Debug.WriteLine(String.Format("Opening container 0x{0}..", serial.ToString("X8")), "World");

                ObjectChanged(serial, ObjectChangeType.ItemOpened);

                return CallbackResult.Normal;
            }
        }

        static uint AddToContainerData(PacketReader reader)
        {
            uint serial = reader.ReadUInt32();

            RealItem item = World.FindRealItem(serial);
            if (item == null)
            {
                item = new RealItem(serial);
                World.Add(item);
            }

            item.Detach();

            item.Graphic = reader.ReadUInt16();

            byte unknown = reader.ReadByte();

            item.Amount = reader.ReadUInt16();

            item.X = reader.ReadUInt16();
            item.Y = reader.ReadUInt16();
            item.Z = 0;
            item.Container = reader.ReadUInt32();
            item.Color = reader.ReadUInt16();

            return serial;
        }

        static CallbackResult OnAddToContainer(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                PacketReader reader = new PacketReader(data);

                if (reader.ReadByte() != 0x25)
                    throw new Exception("Invalid packet passed to OnAddToContainer.");

                uint serial = AddToContainerData(reader);

                ObjectChanged(serial, ObjectChangeType.ItemUpdated);
                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnContainerContents(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                Debug.WriteLine(String.Format("Populating container.."), "World");

                PacketReader reader = new PacketReader(data);

                byte id = reader.ReadByte();
                if (id != 0x3C) throw new Exception("Invalid packet passed to OnContainerContents.");

                ushort blockSize = reader.ReadUInt16();

                if (blockSize != reader.Length)
                    Trace.WriteLine(String.Format("BlockSize ({0}) for dynamic packet 0x11 doesn't meet data lenght ({1}).", data.Length), "World");

                ushort items = reader.ReadUInt16();

                while (items > 0)
                {

                    uint serial = AddToContainerData(reader);
                    ObjectChanged(serial, ObjectChangeType.ItemUpdated);
                    items--;
                }

                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnCharacterAddItem(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0x2E) throw new Exception("Invalid packet passed to OnCharacterAddItem.");

                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 1);

                RealItem item = World.FindRealItem(serial);
                if (item == null)
                {
                    item = new RealItem(serial);
                    World.Add(item);
                }

                item.Detach();

                item.Graphic = ByteConverter.LittleEndian.ToUInt16(data, 5);
                item.Layer = ByteConverter.LittleEndian.ToByte(data, 8);
                item.Color = ByteConverter.LittleEndian.ToUInt16(data, 13);

                item.Container = ByteConverter.LittleEndian.ToUInt32(data, 9);

                RealCharacter chr = World.FindRealCharacter(item.Container);
                if (chr != null)
                {
                    chr.Layers[item.Layer] = item.Serial;
                }

                ObjectChanged(serial, ObjectChangeType.ItemUpdated);

                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnCharacterStatus(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                PacketReader reader = new PacketReader(data);

                if (reader.ReadByte() != 0x11) throw new Exception("Invalid packet passed to OnCharacterStatus.");

                ushort blockSize = reader.ReadUInt16();
                if (data.Length != blockSize)
                    Trace.WriteLine(String.Format("BlockSize ({0}) for dynamic packet 0x11 doesn't meet data lenght ({1}).", data.Length), "World");

                uint serial = reader.ReadUInt32();

                RealCharacter chr = World.FindRealCharacter(serial);
                if (chr == null)
                {
                    Debug.WriteLine(String.Format("Cannot update status for unknown character (serial=0x{0}).", serial.ToString("X8")), "World");
                    return CallbackResult.Normal;
                }

                chr.Name = reader.ReadAnsiString(30);
                chr.Hits = reader.ReadInt16();
                chr.MaxHits = reader.ReadInt16();
                chr.Renamable = reader.ReadByte() > 0;

                byte more = reader.ReadByte();

                if (more > 0)
                {
                    byte gender = reader.ReadByte();
                    chr.Strenght = reader.ReadInt16();
                    chr.Dexterity = reader.ReadInt16();
                    chr.Intelligence = reader.ReadInt16();
                    chr.Stamina = reader.ReadInt16();
                    chr.MaxStamina = reader.ReadInt16();
                    chr.Mana = reader.ReadInt16();
                    chr.MaxMana = reader.ReadInt16();
                    chr.Gold = reader.ReadInt32();
                    chr.Armor = reader.ReadUInt16();
                    chr.Weight = reader.ReadUInt16();
                }

#if WORLDDEBUG
                Debug.WriteLine(String.Format("Character status updated ({0}).", chr.Description), "World");
#endif

                ObjectChanged(serial, ObjectChangeType.CharUpdated);
                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnUpdateStats(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0x2D) throw new Exception("Invalid packet passed to OnUpdateStats.");

                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 1);

                RealCharacter chr = World.FindRealCharacter(serial);
                if (chr == null)
                {
                    Debug.WriteLine(String.Format("Cannot update stats for unknown character (serial=0x{0}).", serial.ToString("X8")), "World");
                    return CallbackResult.Normal;
                }

                chr.MaxHits = ByteConverter.LittleEndian.ToInt16(data, 5);
                chr.Hits = ByteConverter.LittleEndian.ToInt16(data, 7);
                chr.MaxMana = ByteConverter.LittleEndian.ToInt16(data, 9);
                chr.Mana = ByteConverter.LittleEndian.ToInt16(data, 11);
                chr.MaxStamina = ByteConverter.LittleEndian.ToInt16(data, 13);
                chr.Stamina = ByteConverter.LittleEndian.ToInt16(data, 15);

                ObjectChanged(serial, ObjectChangeType.CharUpdated);
                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnUpdateHits(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0xA1) throw new Exception("Invalid packet passed to OnUpdateHits.");

                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 1);

                RealCharacter chr = World.FindRealCharacter(serial);
                if (chr == null)
                {
                    Debug.WriteLine(String.Format("Cannot update hitpoints for unknown character (serial=0x{0}).", serial.ToString("X8")), "World");
                    return CallbackResult.Normal;
                }

                chr.MaxHits = ByteConverter.LittleEndian.ToInt16(data, 5);
                chr.Hits = ByteConverter.LittleEndian.ToInt16(data, 7);

                ObjectChanged(serial, ObjectChangeType.CharUpdated);
                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnUpdateMana(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0xA2) throw new Exception("Invalid packet passed to OnUpdateMana.");

                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 1);

                RealCharacter chr = World.FindRealCharacter(serial);
                if (chr == null)
                {
                    Debug.WriteLine(String.Format("Cannot update mana for unknown character (serial=0x{0}).", serial.ToString("X8")), "World");
                    return CallbackResult.Normal;
                }

                chr.MaxMana = ByteConverter.LittleEndian.ToInt16(data, 5);
                chr.Mana = ByteConverter.LittleEndian.ToInt16(data, 7);

                ObjectChanged(serial, ObjectChangeType.CharUpdated);
                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnUpdateStamina(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0xA3) throw new Exception("Invalid packet passed to OnUpdateStamina.");

                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 1);

                RealCharacter chr = World.FindRealCharacter(serial);
                if (chr == null)
                {
                    Debug.WriteLine(String.Format("Cannot update stamina for unknown character (serial=0x{0}).", serial.ToString("X8")), "World");
                    return CallbackResult.Normal;
                }

                chr.MaxStamina = ByteConverter.LittleEndian.ToInt16(data, 5);
                chr.Stamina = ByteConverter.LittleEndian.ToInt16(data, 7);

                ObjectChanged(serial, ObjectChangeType.CharUpdated);
                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnLoginConfirm(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0x1B) throw new Exception("Invalid packet passed to OnLoginConfirm.");

                World.PlayerSerial = ByteConverter.LittleEndian.ToUInt32(data, 1);

                RealCharacter chr = World.FindRealCharacter(World.PlayerSerial);
                if (chr == null)
                {
                    chr = new RealCharacter(World.PlayerSerial);
                    World.Add(chr);
                }

                chr.Model = ByteConverter.LittleEndian.ToUInt16(data, 9);

                chr.X = ByteConverter.LittleEndian.ToUInt16(data, 11);
                chr.Y = ByteConverter.LittleEndian.ToUInt16(data, 13);
                chr.Z = ByteConverter.LittleEndian.ToSByte(data, 16);

                chr.Direction = ByteConverter.LittleEndian.ToByte(data, 17);

                WalkHandling.ClearStack();

                Debug.WriteLine(String.Format("Player logged in. ({0}).", chr), "World");

                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnPlayerSync(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0x20) throw new Exception("Invalid packet passed to OnPlayerSync.");

                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 1);

                if (World.RealPlayer == null)
                {
                    Trace.WriteLine(String.Format("LoginConfirm packet not received yet."), "World");
                    return CallbackResult.Normal;
                }

                if (World.PlayerSerial != serial)
                    throw new InvalidOperationException("Invalid serial in 0x20 packet.");

                World.RealPlayer.Model = ByteConverter.LittleEndian.ToUInt16(data, 5);
                World.RealPlayer.Color = ByteConverter.LittleEndian.ToUInt16(data, 8);
                World.RealPlayer.Flags = ByteConverter.LittleEndian.ToByte(data, 10);

                World.RealPlayer.X = ByteConverter.LittleEndian.ToUInt16(data, 11);
                World.RealPlayer.Y = ByteConverter.LittleEndian.ToUInt16(data, 13);
                World.RealPlayer.Z = ByteConverter.LittleEndian.ToSByte(data, 18);

                World.RealPlayer.Direction = ByteConverter.LittleEndian.ToByte(data, 17);

                WalkHandling.ClearStack();

                Debug.WriteLine(String.Format("Player updated ({0}).", World.RealPlayer), "World");

                ObjectChanged(serial, ObjectChangeType.CharUpdated);
                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnCharacterUpdate(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                PacketReader reader = new PacketReader(data);

                if (reader.ReadByte() != 0x77) throw new Exception("Invalid packet passed to OnCharacterUpdate.");

                bool newCharacter = false;
                uint serial = reader.ReadUInt32();

                RealCharacter chr = World.FindRealCharacter(serial);
                if (chr == null)
                {
                    chr = new RealCharacter(serial);
                    World.Add(chr);
                    newCharacter = true;
                }

                chr.Model = reader.ReadUInt16();
                chr.X = reader.ReadUInt16();
                chr.Y = reader.ReadUInt16();
                chr.Z = reader.ReadSByte();

                chr.Direction = reader.ReadByte();
                chr.Color = reader.ReadUInt16();
                chr.Flags = reader.ReadByte();
                chr.Notoriety = reader.ReadByte();

#if WORLDDEBUG
                Debug.WriteLine(String.Format("Character updated ({0}).", chr.Description), "World");
#endif

                if (newCharacter)
                    characterAppeared.Invoke(null, new CharacterAppearedEventArgs(serial));

                ObjectChanged(serial, ObjectChangeType.CharUpdated);
                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnCharacterInformation(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                PacketReader reader = new PacketReader(data);

                if (reader.ReadByte() != 0x78) throw new Exception("Invalid packet passed to OnCharacterInformation.");

                ushort blockSize = reader.ReadUInt16();
                if (data.Length != blockSize)
                    Trace.WriteLine(String.Format("BlockSize ({0}) for dynamic packet 0x78 doesn't meet data lenght ({1}).", data.Length), "World");

                bool newCharacter = false;
                uint serial = reader.ReadUInt32();

                RealCharacter chr = World.FindRealCharacter(serial);
                if (chr == null)
                {
                    chr = new RealCharacter(serial);
                    World.Add(chr);
                    newCharacter = true;
                }

                chr.Model = reader.ReadUInt16();
                chr.X = reader.ReadUInt16();
                chr.Y = reader.ReadUInt16();
                chr.Z = reader.ReadSByte();

                chr.Direction = reader.ReadByte();
                chr.Color = reader.ReadUInt16();
                chr.Flags = reader.ReadByte();
                chr.Notoriety = reader.ReadByte();

                if (newCharacter)
                    characterAppeared.Invoke(null, new CharacterAppearedEventArgs(serial));

                ObjectChanged(serial, ObjectChangeType.CharUpdated);

                // Items
                while (reader.Offset < blockSize)
                {
                    uint itemSerial = reader.ReadUInt32();

                    if (itemSerial == 0)
                        return CallbackResult.Normal;

                    RealItem item = World.FindRealItem(itemSerial);
                    if (item == null)
                    {
                        item = new RealItem(itemSerial);
                        World.Add(item);
                    }

                    item.Detach();

                    ushort graphic = reader.ReadUInt16();
                    item.Graphic = (ushort)(graphic & 0x7FFF);

                    item.Layer = reader.ReadByte();

                    if ((graphic & 0x8000) != 0)
                    {
                        item.Color = reader.ReadUInt16();
                    }

                    item.Container = chr.Serial;
                    chr.Layers[item.Layer] = item.Serial;

                    ObjectChanged(itemSerial, ObjectChangeType.ItemUpdated);
                }

#if WORLDDEBUG
                Debug.WriteLine(String.Format("Character updated ({0}).", chr), "World");
#endif

                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnThingName(byte[] data, CallbackResult prevResult)
        {
            // This packet is probably sent for Characters only
            lock (World.SyncRoot)
            {
                if (data[0] != 0x98) throw new Exception("Invalid packet passed to OnThingName.");

                ushort blockSize = ByteConverter.LittleEndian.ToUInt16(data, 1);
                if (data.Length != blockSize)
                    Trace.WriteLine(String.Format("BlockSize ({0}) for dynamic packet 0x98 doesn't meet data lenght ({1}).", data.Length), "World");

                if (blockSize != 37)
                {
                    Trace.WriteLine(String.Format("Invalid 0x98 ThingName packet lenght. Maybe a client version of packet."), "World");
                    return CallbackResult.Normal;
                }

                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 3);

                RealObject obj = World.FindRealObject(serial);
                if (obj == null)
                {
                    Debug.WriteLine(String.Format("Cannot set name for non-existing object (serial=0x{0}).", serial.ToString("X8")), "World");
                    return CallbackResult.Normal;
                }

                string name = ByteConverter.LittleEndian.ToAsciiString(data, 7, 30);
                if (name != obj.Name)
                {
                    obj.Name = name;
                    Debug.WriteLine(String.Format("Object name upadted: {0}", obj), "World");

                    if (obj is RealItem)
                        ObjectChanged(serial, ObjectChangeType.ItemUpdated);
                    else
                        ObjectChanged(serial, ObjectChangeType.CharUpdated);
                }

                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnAsciiSpeech(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                AsciiSpeech packet = new AsciiSpeech(data);

                RealObject obj = World.FindRealObject(packet.Serial);
                if (obj == null)
                {
                    // System speech
                    return CallbackResult.Normal;
                }

                if (obj.Name != packet.Name)
                {
                    obj.Name = packet.Name;
#if WORLDDEBUG
                    Debug.WriteLine(String.Format("Object name upadted: {0}", obj.Description), "World");
#endif

                    if (obj is RealItem)
                        ObjectChanged(obj.Serial, ObjectChangeType.ItemUpdated);
                    else
                        ObjectChanged(obj.Serial, ObjectChangeType.CharUpdated);
                }

                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnUniSpeech(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                UnicodeSpeech packet = new UnicodeSpeech(data);

                RealObject obj = World.FindRealObject(packet.Serial);
                if (obj == null)
                {
                    // System speech
                    return CallbackResult.Normal;
                }

                if (obj.Name != packet.Name)
                {
                    obj.Name = packet.Name;
#if WORLDDEBUG
                    Debug.WriteLine(String.Format("Object name upadted: {0}", obj.Description), "World");
#endif

                    if (obj is RealItem)
                        ObjectChanged(obj.Serial, ObjectChangeType.ItemUpdated);
                    else
                        ObjectChanged(obj.Serial, ObjectChangeType.CharUpdated);
                }

                return CallbackResult.Normal;
            }
        }
    }
}
