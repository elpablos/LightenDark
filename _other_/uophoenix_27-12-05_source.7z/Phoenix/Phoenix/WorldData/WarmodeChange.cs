using System;
using System.Collections.Generic;
using System.Text;

namespace Phoenix.WorldData
{
    public enum WarmodeChange : byte
    {
        Peace = 0,
        War = 1,
        Switch = 2
    }
}
