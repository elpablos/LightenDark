using System;
using System.Collections.Generic;
using System.Text;

namespace Phoenix.WorldData
{
    [Flags]
    public enum ObjectChangeType
    {
        CharUpdated,
        ItemUpdated,
        Removed,
        ItemOpened,
        /// <summary>
        /// Needs a lot of performance testing.
        /// </summary>
        SubItemUpdated, 
        /// <summary>
        /// Needs a lot of performance testing.
        /// </summary>
        SubItemRemoved
    }

    public class ObjectChangedEventArgs : EventArgs
    {
        private Serial serial;
        private Serial itemSerial;
        private ObjectChangeType type;

        public ObjectChangedEventArgs(Serial serial, ObjectChangeType type)
        {
            this.serial = serial;
            this.type = type;
            this.itemSerial = Serial.Invalid;
        }

        public ObjectChangedEventArgs(Serial serial, Serial itemSerial, ObjectChangeType type)
        {
            this.serial = serial;
            this.type = type;
            this.itemSerial = itemSerial;
        }

        /// <summary>
        /// Serial of "caller".
        /// </summary>
        public Serial Serial
        {
            get { return serial; }
        }

        /// <summary>
        /// Serial of changed sub item or Serial.Invalid.
        /// </summary>
        public Serial ItemSerial
        {
            get { return itemSerial; }
        }

        public ObjectChangeType Type
        {
            get { return type; }
        }
    }

    public delegate void ObjectChangedEventHandler(object sender, ObjectChangedEventArgs e);

    internal class ObjectChangedPublicEvent : PublicEvent<ObjectChangedEventHandler, ObjectChangedEventArgs>
    {
    }
}
