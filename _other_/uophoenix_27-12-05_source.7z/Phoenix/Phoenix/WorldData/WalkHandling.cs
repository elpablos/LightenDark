using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace Phoenix.WorldData
{
    static class WalkHandling
    {
        private static Queue<byte> stepStack;
        private static WorldLocation desiredPos;
        private static byte desiredDir;

        /// <summary>
        /// Called by WorldPacketHandler.Init()
        /// </summary>
        internal static void Init()
        {
            spw.Start();
            stepStack = new Queue<byte>();

            Core.RegisterClientMessageCallback(0x02, new MessageCallback(OnWalkRequest));
            Core.RegisterServerMessageCallback(0x21, new MessageCallback(OnWalkRequestFailed));
            Core.RegisterServerMessageCallback(0x22, new MessageCallback(OnWalkRequestSucceed));

            Core.Disconnected += new EventHandler(Core_Disconnected);
        }

        static void Core_Disconnected(object sender, EventArgs e)
        {
            ClearStack();
        }

        internal static void ClearStack()
        {
            lock (World.SyncRoot)
            {
                stepStack.Clear();

                desiredPos = new WorldLocation(World.RealPlayer.X, World.RealPlayer.Y, World.RealPlayer.Z);
                desiredDir = World.RealPlayer.Direction;

                Debug.WriteLine("Step stack cleared.", "World");
            }
        }

        static System.Diagnostics.Stopwatch spw = new Stopwatch();

        static CallbackResult OnWalkRequest(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0x02) throw new Exception("Invalid packet passed to OnWalkRequest.");

                stepStack.Enqueue(data[1]);

                if ((desiredDir & 0x0F) == (data[1] & 0x0F))
                {
                    switch (data[1] & 0x0F)
                    {
                        case 0:
                            desiredPos.Y--;
                            break;
                        case 1:
                            desiredPos.Y--;
                            desiredPos.X++;
                            break;
                        case 2:
                            desiredPos.X++;
                            break;
                        case 3:
                            desiredPos.Y++;
                            desiredPos.X++;
                            break;
                        case 4:
                            desiredPos.Y++;
                            break;
                        case 5:
                            desiredPos.Y++;
                            desiredPos.X--;
                            break;
                        case 6:
                            desiredPos.X--;
                            break;
                        case 7:
                            desiredPos.Y--;
                            desiredPos.X--;
                            break;
                        default:
                            Trace.WriteLine("Invalid direction requested.", "World");
                            return CallbackResult.Normal;
                    }
                }

                desiredDir = data[1];

                //UO.Print("{0} ms", spw.ElapsedMilliseconds);
                spw.Reset();
                spw.Start();

                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnWalkRequestFailed(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0x21) throw new Exception("Invalid packet passed to OnWalkRequestFailed.");

                World.RealPlayer.X = ByteConverter.LittleEndian.ToUInt16(data, 2);
                World.RealPlayer.Y = ByteConverter.LittleEndian.ToUInt16(data, 4);
                World.RealPlayer.Direction = data[6];
                World.RealPlayer.Z = (sbyte)data[7];

                ClearStack();

                WorldPacketHandler.ObjectCallbacks.InvokeAsync(new ObjectChangedEventArgs(World.PlayerSerial, ObjectChangeType.CharUpdated));
                return CallbackResult.Normal;
            }
        }

        static CallbackResult OnWalkRequestSucceed(byte[] data, CallbackResult prevResult)
        {
            lock (World.SyncRoot)
            {
                if (data[0] != 0x22) throw new Exception("Invalid packet passed to OnWalkRequestSucceed.");

                if (stepStack.Count == 0)
                {
                    Trace.WriteLine(String.Format("Walk stack is empty."), "World");
                    return CallbackResult.Eat;
                }

                byte dir = stepStack.Dequeue();

                if ((World.RealPlayer.Direction & 0x0F) == (dir & 0x0F))
                {
                    switch (dir & 0x0F)
                    {
                        case 0:
                            World.RealPlayer.Y--;
                            break;
                        case 1:
                            World.RealPlayer.Y--;
                            World.RealPlayer.X++;
                            break;
                        case 2:
                            World.RealPlayer.X++;
                            break;
                        case 3:
                            World.RealPlayer.Y++;
                            World.RealPlayer.X++;
                            break;
                        case 4:
                            World.RealPlayer.Y++;
                            break;
                        case 5:
                            World.RealPlayer.Y++;
                            World.RealPlayer.X--;
                            break;
                        case 6:
                            World.RealPlayer.X--;
                            break;
                        case 7:
                            World.RealPlayer.Y--;
                            World.RealPlayer.X--;
                            break;
                        default:
                            Trace.WriteLine("Invalid direction in step stack.", "World");
                            return CallbackResult.Normal;
                    }
                }

                World.RealPlayer.Direction = dir;

                WorldPacketHandler.ObjectCallbacks.InvokeAsync(new ObjectChangedEventArgs(World.PlayerSerial, ObjectChangeType.CharUpdated));
                return CallbackResult.Normal;
            }
        }
    }
}
