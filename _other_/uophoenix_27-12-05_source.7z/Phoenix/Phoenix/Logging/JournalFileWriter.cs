using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Phoenix.WorldData;

namespace Phoenix
{
    internal class JournalFileWriter
    {
        private TextWriter writer;

        public JournalFileWriter(string file)
        {
            writer = File.AppendText(file);

            Core.Disconnected += new EventHandler(Core_Disconnected);
            Logging.JournalHandler.JournalEntryAdded += new JournalEntryAddedEventHandler(JournalHandler_JournalEntryAdded);
        }

        void Core_Disconnected(object sender, EventArgs e)
        {
            writer.Flush();
        }

        void JournalHandler_JournalEntryAdded(object sender, JournalEntryAddedEventArgs e)
        {
            string line = String.Format("{0} {1}", e.Entry.TimeStamp, e.Entry);
            writer.WriteLine(line);
        }

        public void Flush()
        {
            writer.Flush();
        }
    }
}
