using System;
using System.Collections.Generic;
using System.Text;

namespace Phoenix
{
    /// <summary>
    /// Not implemented yet.
    /// </summary>
    public abstract class OptionalParameterAttribute : Attribute
    {
    }
}
