using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Globalization;
using Phoenix.Communication;
using Phoenix.Configuration;
using Phoenix.WorldData;
using Phoenix.Runtime;

namespace Phoenix
{
    public static partial class UO
    {
        [Command]
        public static void Exec(string script, params object[] args)
        {
            RuntimeCore.Executions.Execute(RuntimeCore.ExecutableList[script], args);
        }

        [Command]
        public static object Run(string script, params object[] args)
        {
            return RuntimeCore.Executions.Run(RuntimeCore.ExecutableList[script], args);
        }

        [Command]
        public static void TerminateAll()
        {
            RuntimeCore.Executions.TerminateAll();
        }

        /// <summary>
        /// Blocks the current execution for a specified time.
        /// </summary>
        /// <param name="milliseconds">The number of milliseconds for which the thread is blocked.</param>
        [Command("wait")]
        public static void Wait(int milliseconds)
        {
            System.Threading.Thread.Sleep(milliseconds);
        }

        [Command]
        public static void Hide()
        {
            Serial serial = UIManager.TargetObject();
            Wait(500); // Client crashes if object that was targetted is instantly removed.
            Hide(serial);
        }

        [Command]
        public static void Hide(Serial serial)
        {
            if (serial.IsValid)
            {
                Core.SendToClient(PacketBuilder.ObjectRemove(serial));
            }
            else
            {
                ScriptErrorException.Throw("Invalid serial.");
            }
        }

        [Command]
        [BlockMultipleExecutions]
        public static bool BandageSelf()
        {
            UOItem bandages = World.Player.Backpack.AllItems.FindType(0x0E21);

            if (bandages.Exist)
            {
                UO.WaitTargetSelf();
                bandages.Use();
                return true;
            }
            else
            {
                ScriptErrorException.Throw("No bandages found.");
                return false;
            }
        }

        [Command("info")]
        public static void Info()
        {
            Info(UIManager.TargetObject());
        }

        [Command("info")]
        public static void Info(Serial serial)
        {
            if (World.GetObject(serial).Exist)
            {
                Notepad.WriteLine(World.GetObject(serial).Description);
                Notepad.WriteLine();
            }
        }

        [Command("version")]
        public static void Version()
        {
            Version(false);
        }

        [Command("version")]
        public static void Version(bool details)
        {
            UO.Say(0x35, "{0} is currently using {1} v{2}", World.RealPlayer.Name, Core.VersionString, Core.Version);

            if (details)
            {
                UO.Say(0x35, "Latency {0} ms", Core.Latency);
            }
        }

        [Command]
        public static void RemoveJewelry()
        {
            World.Player.Layers[Layer.Ring].Move(0, World.Player.Backpack);
            World.Player.Layers[Layer.Bracelet].Move(0, World.Player.Backpack);
            World.Player.Layers[Layer.Earrings].Move(0, World.Player.Backpack);

            UOItem neck = World.Player.Layers[Layer.Neck];

            Graphic[] neclases = new Graphic[] { 0x1085, 0x1088, 0x1089, 0x1F05, 0x1F08, 0x1F0A };
            if (Array.IndexOf<Graphic>(neclases, neck.Graphic) >= 0)
            {
                neck.Move(0, World.Player.Backpack);
            }
        }

        /// <summary>
        /// This function ins provided only for compatilibity with Injection. If you can avoid it don't use it.
        /// Objects are deleted on logout.
        /// </summary>
        /// <param name="name">Can contain only letters. It is not case sensitive.</param>
        [Command]
        public static void AddObject(string name)
        {
            if (Helper.CheckName(ref name, false))
            {
                UO.Print("Select {0}:", name);

                Serial serial = UIManager.TargetObject();

                if (serial.IsValid)
                    Aliases.SetObject(name, serial);
                else
                    ScriptErrorException.Throw("Invalid object serial.");
            }
            else
            {
                ScriptErrorException.Throw("Invalid object name.");
            }
        }

        /// <summary>
        /// This function ins provided only for compatilibity with Injection. If you can avoid it don't use it.
        /// Objects are deleted on logout.
        /// </summary>
        /// <param name="name">Can contain only letters. It is not case sensitive.</param>
        [Command]
        public static void AddObject(string name, Serial value)
        {
            if (Helper.CheckName(ref name, false))
            {
                Aliases.SetObject(name, value);
            }
            else
            {
                ScriptErrorException.Throw("Invalid object name.");
            }
        }
    }
}
