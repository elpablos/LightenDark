using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Phoenix.Configuration;

namespace Phoenix
{
    public static class Config
    {
        #region PacketLogging class

        public class PacketLogging
        {
            private SettingBoolEntry enable;
            private SettingBoolEntry clientToPhoenix;
            private SettingBoolEntry phoenixToServer;
            private SettingBoolEntry serverToPhoenix;
            private SettingBoolEntry phoenixToClient;

            private DefaultPublicEvent changed;

            internal PacketLogging(ISettings settings)
            {
                changed = new DefaultPublicEvent();

                enable = new SettingBoolEntry(settings, false, "Enable", "Config", "PacketLogging");
                clientToPhoenix = new SettingBoolEntry(settings, true, "ClientToPhoenix", "Config", "PacketLogging");
                phoenixToServer = new SettingBoolEntry(settings, false, "PhoenixToServer", "Config", "PacketLogging");
                serverToPhoenix = new SettingBoolEntry(settings, true, "ServerToPhoenix", "Config", "PacketLogging");
                phoenixToClient = new SettingBoolEntry(settings, false, "PhoenixToClient", "Config", "PacketLogging");

                enable.Changed += new EventHandler(packetLogging_Changed);
                clientToPhoenix.Changed += new EventHandler(packetLogging_Changed);
                phoenixToServer.Changed += new EventHandler(packetLogging_Changed);
                serverToPhoenix.Changed += new EventHandler(packetLogging_Changed);
                phoenixToClient.Changed += new EventHandler(packetLogging_Changed);
            }

            void packetLogging_Changed(object sender, EventArgs e)
            {
                changed.Invoke(sender, e);
            }

            public event EventHandler Changed
            {
                add { changed.AddHandler(value); }
                remove { changed.RemoveHandler(value); }
            }

            public SettingBoolEntry Enable
            {
                get { return enable; }
            }

            public SettingBoolEntry ClientToPhoenix
            {
                get { return clientToPhoenix; }
            }

            public SettingBoolEntry PhoenixToServer
            {
                get { return phoenixToServer; }
            }

            public SettingBoolEntry ServerToPhoenix
            {
                get { return serverToPhoenix; }
            }

            public SettingBoolEntry PhoenixToClient
            {
                get { return phoenixToClient; }
            }
        }

        #endregion

        private static Settings settings;
        private static ProfileConfig profile;
        private static PacketLogging packetLogging;

        private static SettingInt32Entry groundFindDistance;
        private static SettingInt32Entry resyncInterval;

        static Config()
        {
            settings = new SynchronizedSettings("Phoenix");
            profile = null;
            packetLogging = new PacketLogging(settings);

            groundFindDistance = new SettingInt32Entry(settings, 8, "FindDistance", "Config", "World");
            resyncInterval = new SettingInt32Entry(settings, 5, "ResyncInterval", "Config");
        }

        /// <summary>
        /// Called by Phoenix.Init()
        /// </summary>
        internal static void Init()
        {
            profile = new ProfileConfig(System.IO.Path.Combine(Core.Directory, "Profiles"));
        }

        internal static Settings Settings
        {
            get { return Config.settings; }
        }

        public static ProfileConfig Profile
        {
            get { return Config.profile; }
        }

        public static PacketLogging PacketLog
        {
            get { return packetLogging; }
        }

        public static SettingInt32Entry GroundFindDistance
        {
            get { return Config.groundFindDistance; }
        }

        internal static SettingInt32Entry ResyncInterval
        {
            get { return Config.resyncInterval; }
        }

        [Command("saveconfig")]
        public static void Save()
        {
            settings.Save();
            profile.Save();
            UO.Print("Configuration saved.");
            Trace.Flush();
        }

        internal static string PlayerProfile
        {
            get
            {
                if (WorldData.World.RealPlayer == null)
                    throw new InvalidOperationException("No player logged in.");

                string playerSerial = WorldData.World.PlayerSerial.ToString("X8");
                return Config.Settings.GetAttribute(playerSerial, "profile", "Characters", new ElementInfo("Character", new AttributeInfo("serial", playerSerial)));
            }
            set
            {
                if (WorldData.World.RealPlayer == null)
                    throw new InvalidOperationException("No player logged in.");

                string playerSerial = WorldData.World.PlayerSerial.ToString("X8");
                Config.Settings.SetAttribute(value, "profile", "Characters", new ElementInfo("Character", new AttributeInfo("serial", playerSerial)));
            }
        }
    }
}
