using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Phoenix.Communication;
using Phoenix.Configuration;
using Phoenix.WorldData;

namespace Phoenix
{
    partial class UO
    {
        [ThreadStatic]
        public static bool UseUnicodePrint;

        public static void Print(object o)
        {
            if (o != null)
                PrintInternal("Phoenix", o.ToString(), Env.ConsoleColor, SpeechFont.Normal, SpeechType.Regular);
        }

        [Command]
        public static void Print(string text)
        {
            PrintInternal("Phoenix", text, Env.ConsoleColor, SpeechFont.Normal, SpeechType.Regular);
        }

        public static void Print(string format, params object[] args)
        {
            string text = String.Format(format, args);
            PrintInternal("Phoenix", text, Env.ConsoleColor, SpeechFont.Normal, SpeechType.Regular);
        }

        public static void Print(ushort color, string format, params object[] args)
        {
            string text = String.Format(format, args);
            PrintInternal("Phoenix", text, color, SpeechFont.Normal, SpeechType.Regular);
        }

        public static void Print(SpeechFont font, ushort color, string format, params object[] args)
        {
            string text = String.Format(format, args);
            PrintInternal("Phoenix", text, color, font, SpeechType.Regular);
        }

        public static void PrintInformation(string format, params object[] args)
        {
            string text = String.Format(format, args);
            PrintInternal("Information", text, Env.InfoColor, SpeechFont.Normal, SpeechType.Regular);
        }

        public static void PrintWarning(string format, params object[] args)
        {
            string text = String.Format(format, args);
            PrintInternal("Warning", text, Env.WarningColor, SpeechFont.Normal, SpeechType.Regular);
        }

        public static void PrintError(string format, params object[] args)
        {
            string text = String.Format(format, args);
            PrintInternal("Error", text, Env.ErrorColor, SpeechFont.Normal, SpeechType.Regular);
        }

        private static void PrintInternal(string speaker, string text, ushort color, SpeechFont font, SpeechType type)
        {
            if (text != null)
            {
                Logging.JournalHandler.Print(new JournalEntry(DateTime.Now, 0xFFFFFFFF, speaker, text, color, type, font, JournalEntrySource.Phoenix));

                string[] lines = text.Split('\n');
                for (int i = 0; i < lines.Length; i++)
                {
                    byte[] data;

                    if (UseUnicodePrint)
                        data = PacketBuilder.CharacterSpeechUnicode(0xFFFFFFFF, 0xFFFF, speaker, type, font, color, lines[i]);
                    else
                        data = PacketBuilder.CharacterSpeechAscii(0xFFFFFFFF, 0xFFFF, speaker, type, font, color, lines[i]);

                    Core.SendToClient(data);
                }
            }
        }

        [Command("say")]
        public static void Say(string text)
        {
            SayInternal(SpeechType.Regular, Env.FontColor, text);
        }

        public static void Say(string format, params object[] args)
        {
            Say(SpeechType.Regular, Env.FontColor, format, args);
        }

        public static void Say(ushort color, string format, params object[] args)
        {
            Say(SpeechType.Regular, color, format, args);
        }

        public static void Say(SpeechType type, ushort color, string format, params object[] args)
        {
            string text = String.Format(format, args);
            SayInternal(type, color, text);
        }

        private static void SayInternal(SpeechType type, ushort color, string text)
        {
            string[] lines = text.Split('\n');
            for (int i = 0; i < lines.Length; i++)
            {
                string line = "";

                for (int x = 0; x < lines[i].Length; x++)
                {
                    if (lines[i][x] >= ' ')
                        line += lines[i][x];
                }

                byte[] data = PacketBuilder.SpeechRequestUnicode(type, SpeechFont.Normal, color, line);
                Core.SendToServer(data);
            }
        }

        public static void Talk(Serial serial, string format, params object[] args)
        {
            Talk(serial, Env.FontColor, format, args);
        }

        /// <summary>
        /// Prints text above object of specified id (like if it said it but you are the only one who see it).
        /// </summary>
        /// <param name="serial"></param>
        /// <param name="color"></param>
        /// <param name="format"></param>
        /// <param name="args"></param>
        /// <remarks>When object doesn't exist in object it acts like Print.</remarks>
        public static void Talk(Serial serial, ushort color, string format, params object[] args)
        {
            string text = String.Format(format, args);
            Logging.JournalHandler.Print(new JournalEntry(DateTime.Now, serial, WorldData.World.Player.Name, text, color, SpeechType.Regular, SpeechFont.Normal, JournalEntrySource.Phoenix));

            string[] lines = text.Replace("\r", "").Split('\n');
            for (int i = 0; i < lines.Length; i++)
            {
                byte[] data = PacketBuilder.CharacterSpeechUnicode(serial, WorldData.World.Player.Model, WorldData.World.Player.Name, SpeechType.Regular, SpeechFont.Normal, color, lines[i]);
                Core.SendToClient(data);
            }
        }
    }
}
