using System;
using System.Collections.Generic;
using System.Text;
using Phoenix.WorldData;
using Phoenix.Communication;

namespace Phoenix
{
    partial class UO
    {
        [Command]
        public static void Warmode(bool enabled)
        {
            Core.SendToServer(PacketBuilder.Warmode(Convert.ToByte(enabled)));
        }

        [Command]
        public static void UseSkill(ushort id)
        {
            Core.SendToServer(PacketBuilder.UseSkill(id));
        }

        [Command]
        public static void UseSkill(string skill)
        {
            skill = skill.ToLowerInvariant();

            for (int i = 0; i < DataFiles.Skills.Count; i++)
            {
                if (DataFiles.Skills[i].Name.ToLowerInvariant().Contains(skill))
                {
                    UseSkill((ushort)i);
                    return;
                }
            }

            ScriptErrorException.Throw("Unknown skill '{0}'", skill);
        }

        public static void UseSkill(StandardSkills skill)
        {
            Core.SendToServer(PacketBuilder.UseSkill((ushort)skill));
        }

        [Command]
        public static void Cast(byte spellnum)
        {
            Core.SendToServer(PacketBuilder.CastSpell(spellnum));
        }

        [Command]
        public static void Cast(byte spellnum, Serial target)
        {
            if (target.IsValid)
                UIManager.WaitForTarget(target, 0, 0, 0, 0);

            Core.SendToServer(PacketBuilder.CastSpell(spellnum));
        }

        [Command]
        public static void Cast(string spellname)
        {
            Cast(spellname, Serial.Invalid);
        }

        [Command]
        public static void Cast(string spellname, Serial target)
        {
            Byte spellNum;

            if (Core.SpellList.TryFind(spellname, out spellNum))
            {
                if (target.IsValid)
                    UIManager.WaitForTarget(target, 0, 0, 0, 0);

                Core.SendToServer(PacketBuilder.CastSpell(spellNum));
            }
            else
            {
                ScriptErrorException.Throw("Unknown spell '{0}'", spellname);
            }
        }

        public static void Cast(StandardSpells spell)
        {
            Cast(spell, Serial.Invalid);
        }

        public static void Cast(StandardSpells spell, Serial target)
        {
            if (target.IsValid)
                UIManager.WaitForTarget(target, 0, 0, 0, 0);

            Core.SendToServer(PacketBuilder.CastSpell((byte)spell));
        }


        [Command]
        public static void Attack()
        {
            Serial s = UIManager.TargetObject();
            if (s.IsValid)
                Attack(s);
        }

        [Command]
        public static void Attack(Serial serial)
        {
            if (serial.IsValid)
                Core.SendToServer(PacketBuilder.AttackRequest(serial));
            else
                ScriptErrorException.Throw("Invalid serial.");
        }

        [Command("summon")]
        public static void SummonCreature(string summon)
        {
            SummonCreature(summon, Serial.Invalid);
        }

        [Command("summon")]
        public static void SummonCreature(string summon, Serial target)
        {
            UIManager.WaitForMenu(new MenuSelection("summon", summon));

            if (target.IsValid)
                UIManager.EnqueueWaitForTarget(target, 0, 0, 0, 0);

            UO.Cast("Summ. Creature");
        }
    }
}
