using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Security;

namespace Phoenix
{
    static class NativeTimer
    {
        [SuppressUnmanagedCodeSecurity]
        [DllImport("winmm.dll")]
        public static extern uint timeGetTime();
    }
}
