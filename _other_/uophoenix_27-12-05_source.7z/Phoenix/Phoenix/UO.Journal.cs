using System;
using System.Collections.Generic;
using System.Text;

namespace Phoenix
{
    partial class UO
    {
        public static bool InJournal(string text)
        {
            return Journal.Contains(text);
        }

        [Command]
        public static void DeleteJournal()
        {
            Journal.Clear();
        }
    }
}
