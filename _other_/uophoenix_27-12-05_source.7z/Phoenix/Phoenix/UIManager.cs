using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Diagnostics;
using Phoenix.Communication;
using Phoenix.Communication.Packets;
using Phoenix.WorldData;

namespace Phoenix
{
    public static class UIManager
    {
        public const int PhoenixTargetTimeout = 120;
        public const int WaitTargetTimeout = 30;
        public const int WaitMenuTimeout = 30;
        public const int PhoenixMoveItemTimeout = 30;

        #region OperationResult and WaitQuery classes

        private class OperationResult
        {
            public bool Success = false;
            public readonly AutoResetEvent Event = new AutoResetEvent(false);
        }

        private class WaitQuery
        {
            public WaitQuery(TargetInfo target)
            {
                ThreadId = Thread.CurrentThread.ManagedThreadId;
                Target = target;
                Menu = new MenuSelection();
            }

            public WaitQuery(MenuSelection menu)
            {
                ThreadId = Thread.CurrentThread.ManagedThreadId;
                Target = null;
                Menu = menu;
            }

            public readonly int ThreadId;
            public TargetInfo Target;
            public MenuSelection Menu;

            public bool IsMenu
            {
                get { return Target == null; }
            }
        }

        #endregion

        private enum State
        {
            Ready,
            Target,
            ServerTarget,
            WaitTarget,
            WaitMenu,
            ClientPickedUpItem,
            ClientHoldingItem,
            ClientDroppedItem,
            MoveItem,
        }

        private static readonly object syncRoot = new object();
        private static State currentState = State.Ready;
        private static AutoResetEvent readySignal = new AutoResetEvent(true);
        private static OperationResult operationResult = null;
        private static Thread timeoutThread = null;

        private static uint pickedUpItem = 0;
        private static string pickedUpItemName = null;
        private static TargetInfo targetInfo = null;
        private static Queue<WaitQuery> waitQueue = null;

        private static State CurrentState
        {
            get { return currentState; }
            set
            {
                if (value != currentState)
                {
                    currentState = value;
                    Debug.WriteLine("CurrentState changed to " + currentState.ToString(), "UIManager");
                }
            }
        }

        public static uint PickedUpItem
        {
            get { return UIManager.pickedUpItem; }
            set
            {
                if (pickedUpItem != 0)
                    World.RemoveObjectChangedCallback(pickedUpItem, new ObjectChangedEventHandler(World_ObjectChanged));

                UIManager.pickedUpItem = value;

                if (pickedUpItem != 0)
                    World.AddObjectChangedCallback(pickedUpItem, new ObjectChangedEventHandler(World_ObjectChanged));
            }
        }

        private static void FinishWork()
        {
            lock (syncRoot)
            {
                if (CurrentState != State.Ready)
                {
                    StopTimeout();

                    if (CurrentState == State.WaitTarget || CurrentState == State.WaitMenu)
                    {
                        Debug.Assert(waitQueue != null, "waitQueue == null");

                        if (waitQueue.Count > 0)
                        {
                            if (waitQueue.Peek().IsMenu)
                            {
                                CurrentState = State.WaitMenu;
                            }
                            else
                            {
                                CurrentState = State.WaitTarget;
                            }
                            return;
                        }
                        else
                        {
                            waitQueue = null;
                        }
                    }

                    CurrentState = State.Ready;
                    readySignal.Set();
                }
            }
        }

        /// <summary>
        /// Called by Phoenix.Initialization()
        /// </summary>
        internal static void Init()
        {
            // Item pickup handling
            Core.RegisterClientMessageCallback(0x07, new MessageCallback(OnPickupRequest), CallbackPriority.High);
            Core.RegisterClientMessageCallback(0x08, new MessageCallback(OnDropRequest), CallbackPriority.High);
            Core.RegisterClientMessageCallback(0x13, new MessageCallback(OnEquipRequest), CallbackPriority.High);
            Core.RegisterServerMessageCallback(0x27, new MessageCallback(OnPickupItemFailed), CallbackPriority.High);
            Core.RegisterServerMessageCallback(0x1D, new MessageCallback(OnRemoveObject), CallbackPriority.High);

            // Targets handling
            Core.RegisterServerMessageCallback(0x6C, new MessageCallback(OnServerTarget), CallbackPriority.High);
            Core.RegisterClientMessageCallback(0x6C, new MessageCallback(OnClientTarget), CallbackPriority.High);

            // ObjectPicker handling
            Core.RegisterServerMessageCallback(0x7C, new MessageCallback(OnObjectPicker), CallbackPriority.High);

            // Actions
            Core.RegisterClientMessageCallback(0x06, new MessageCallback(OnObjectDoubleClick), CallbackPriority.High);
            Core.RegisterClientMessageCallback(0x12, new MessageCallback(OnUse), CallbackPriority.High);
            Core.RegisterClientMessageCallback(0xBF, new MessageCallback(OnGeneralCommand), CallbackPriority.High);

            Core.Disconnected += new EventHandler(Core_Disconnected);
        }

        static void Core_Disconnected(object sender, EventArgs e)
        {
            Reset();
        }

        #region BeginTimeout function

        private static void StopTimeout()
        {
            if (timeoutThread != null)
            {
                timeoutThread.Abort();
                timeoutThread = null;
            }
        }

        private static void BeginTimeout(int seconds)
        {
            StopTimeout();

            timeoutThread = new Thread(new ParameterizedThreadStart(TimeoutThread));
            timeoutThread.Start(seconds * 1000);
        }

        private static void TimeoutThread(object parameter)
        {
            Thread.Sleep((int)parameter);

            lock (syncRoot)
            {
                if (CurrentState != State.Ready)
                {
                    UO.Print("{0} timeout.", CurrentState);
                    ResetInternal(true);
                }
            }
        }

        #endregion

        #region Item manipulation related routines

        private static CallbackResult OnPickupRequest(byte[] data, CallbackResult prevResult)
        {
            lock (syncRoot)
            {
                switch (CurrentState)
                {
                    case State.Ready:
                        break;

                    case State.ClientDroppedItem:
                    case State.MoveItem:
                        Core.SendToClient(PacketBuilder.PickupItemFailed(6));
                        UO.Print("Cannot pick up item now.");
                        return CallbackResult.Eat;

                    default:
                        Reset();
                        break;
                }

                Debug.Assert(CurrentState == State.Ready, "CurrentState is not Ready. Internal error.");

                PickedUpItem = ByteConverter.LittleEndian.ToUInt32(data, 1);

                RealObject obj = World.FindRealObject(PickedUpItem);
                if (obj != null && obj.Name != null && obj.Name.Length > 0)
                    pickedUpItemName = String.Format("\"{0}\"", obj.Name);
                else
                    pickedUpItemName = String.Format("0x{0:X8}", PickedUpItem);

                CurrentState = State.ClientPickedUpItem;

                return CallbackResult.Normal;
            }
        }

        private static CallbackResult OnDropRequest(byte[] data, CallbackResult prevResult)
        {
            lock (syncRoot)
            {
                if (CurrentState != State.ClientPickedUpItem && CurrentState != State.ClientHoldingItem)
                {
                    Trace.WriteLine("Dropped unexpected client drop request.", "UIManager");
                    return CallbackResult.Eat;
                }

                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 1);

                if (serial != PickedUpItem)
                {
                    Trace.WriteLine("Trying to drop incorrect item. Packet dropped.", "UIManager");
                    Reset();
                    return CallbackResult.Eat;
                }

                if (CurrentState == State.ClientHoldingItem)
                {
                    PickedUpItem = 0;
                    pickedUpItemName = null;
                    FinishWork();
                }
                else
                {
                    CurrentState = State.ClientDroppedItem;
                }

                return CallbackResult.Normal;
            }
        }

        private static CallbackResult OnEquipRequest(byte[] data, CallbackResult prevResult)
        {
            lock (syncRoot)
            {
                if (CurrentState != State.ClientPickedUpItem && CurrentState != State.ClientHoldingItem)
                {
                    Trace.WriteLine("Dropped unexpected client equip request.", "UIManager");
                    return CallbackResult.Eat;
                }

                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 1);

                if (serial != PickedUpItem)
                {
                    Trace.WriteLine("Trying to equip incorrect item. Packet dropped.", "UIManager");
                    Reset();
                    return CallbackResult.Eat;
                }

                if (CurrentState == State.ClientHoldingItem)
                {
                    PickedUpItem = 0;
                    pickedUpItemName = null;
                    FinishWork();
                }
                else
                {
                    CurrentState = State.ClientDroppedItem;
                }

                return CallbackResult.Normal;
            }
        }

        private static CallbackResult OnPickupItemFailed(byte[] data, CallbackResult prevResult)
        {
            lock (syncRoot)
            {
                switch (CurrentState)
                {
                    case State.ClientPickedUpItem:
                        PickedUpItem = 0;
                        pickedUpItemName = null;
                        FinishWork();
                        return CallbackResult.Normal;

                    case State.ClientDroppedItem:
                        PickedUpItem = 0;
                        pickedUpItemName = null;
                        FinishWork();
                        return CallbackResult.Eat;

                    case State.MoveItem:
                        operationResult.Success = false;
                        operationResult.Event.Set();
                        operationResult = null;
                        PickedUpItem = 0;
                        pickedUpItemName = null;
                        FinishWork();
                        return CallbackResult.Eat;

                    default:
                        Trace.WriteLine("Dropped unexpected server PickupItemFailed packet.", "UIManager");
                        return CallbackResult.Eat;
                }
            }
        }

        private static CallbackResult OnRemoveObject(byte[] data, CallbackResult prevResult)
        {
            lock (syncRoot)
            {
                uint serial = ByteConverter.LittleEndian.ToUInt32(data, 1);

                if (serial == PickedUpItem)
                {
                    switch (CurrentState)
                    {
                        case State.ClientDroppedItem:
                            PickedUpItem = 0;
                            pickedUpItemName = null;
                            FinishWork();
                            break;

                        case State.ClientPickedUpItem:
                            CurrentState = State.ClientHoldingItem;
                            break;

                        case State.MoveItem:
                            operationResult.Success = true;
                            operationResult.Event.Set();
                            operationResult = null;
                            PickedUpItem = 0;
                            pickedUpItemName = null;
                            FinishWork();
                            break;
                    }

                    return CallbackResult.Normal;
                }
                else
                {
                    return CallbackResult.Normal;
                }
            }
        }

        static void World_ObjectChanged(object sender, ObjectChangedEventArgs e)
        {
            Debug.Assert(e.Serial == PickedUpItem);

            if (e.Type == ObjectChangeType.ItemUpdated)
            {
                lock (syncRoot)
                {
                    switch (CurrentState)
                    {
                        case State.ClientPickedUpItem:
                        case State.ClientHoldingItem:
                        case State.MoveItem:
                            Debug.WriteLine("Warning: Unexpected item update.", "UIManager");
                            return;

                        case State.ClientDroppedItem:
                            PickedUpItem = 0;
                            pickedUpItemName = null;
                            FinishWork();
                            return;

                        default:
                            Trace.WriteLine("pickedUpItem not cleared. Internal error.", "UIManager");
                            PickedUpItem = 0;
                            return;
                    }
                }
            }
        }

        #endregion

        #region Targetting and all around

        private static CallbackResult OnServerTarget(byte[] data, CallbackResult prevResult)
        {
            lock (syncRoot)
            {
                if (CurrentState == State.WaitTarget)
                {
                    Debug.Assert(waitQueue != null && waitQueue.Count > 0, "Empty waitQueue.");
                    Debug.Assert(!waitQueue.Peek().IsMenu, "Target in top of the queue instead of menu.");

                    TargetInfo target = TargetInfo.FromData(data);
                    TargetInfo waitTarget = waitQueue.Dequeue().Target;

                    if (target.Type < waitTarget.Type)
                    {
                        Trace.WriteLine("Unexpected Server target type received. Target passed to client.", "UIManager");
                    }
                    else
                    {
                        waitTarget.TargetId = target.TargetId;
                        Core.SendToServer(waitTarget.ToData());

                        FinishWork();
                        Trace.WriteLine("Processed expected Server target.", "UIManager");
                        return CallbackResult.Eat;
                    }
                }

                if (CurrentState == State.ServerTarget)
                {
                    TargetInfo target = TargetInfo.FromData(data);

                    if (target.Flags == 0x03)
                    {
                        Trace.WriteLine("Cancel-target packet passed to client.", "UIManager");
                        return CallbackResult.Normal;
                    }
                    else
                    {
                        Trace.WriteLine("Warning: Server target updated without previous cancellation.", "UIManager");
                        targetInfo = target;
                        return CallbackResult.Normal;
                    }
                }

                if (CurrentState != State.Ready)
                {
                    Reset();
                }

                Debug.Assert(CurrentState == State.Ready, "CurrentState is not Ready. Internal error.");

                targetInfo = TargetInfo.FromData(data);
                CurrentState = State.ServerTarget;
            }
            return CallbackResult.Normal;
        }

        private static CallbackResult OnClientTarget(byte[] data, CallbackResult prevResult)
        {
            lock (syncRoot)
            {
                switch (CurrentState)
                {
                    case State.ServerTarget:
                        targetInfo = null;
                        FinishWork();
                        return CallbackResult.Normal;

                    case State.Target:
                        TargetInfo target = TargetInfo.FromData(data);

                        if (target.TargetId == targetInfo.TargetId && target.Type == targetInfo.Type)
                        {
                            targetInfo.Serial = target.Serial;
                            targetInfo.X = target.X;
                            targetInfo.Y = target.Y;
                            targetInfo.Z = target.Z;
                            targetInfo.Graphic = target.Graphic;
                        }
                        else
                        {
                            Trace.WriteLine("Incorrect target received from client.", "UIManager");
                        }

                        operationResult.Event.Set();
                        operationResult = null;
                        targetInfo = null;
                        FinishWork();
                        return CallbackResult.Eat;

                    default:
                        Trace.WriteLine("Dropped unexpected client target.", "UIManager");
                        return CallbackResult.Eat;
                }
            }
        }

        #endregion

        #region ObjectPicker handling

        private static CallbackResult OnObjectPicker(byte[] data, CallbackResult prevResult)
        {
            lock (syncRoot)
            {
                if (CurrentState == State.WaitMenu)
                {
                    Debug.Assert(waitQueue != null && waitQueue.Count > 0, "Empty waitQueue.");
                    Debug.Assert(waitQueue.Peek().IsMenu, "Target in top of the queue instead of menu.");

                    Menu packet = new Menu(data);
                    MenuSelection menu = waitQueue.Dequeue().Menu;

                    if (packet.Title.ToLowerInvariant().Contains(menu.Name.ToLowerInvariant()))
                    {
                        // Cancel menu
                        if (menu.Option == null)
                        {
                            byte[] selectedData = PacketBuilder.ObjectPicked(packet.DialogSerial, packet.MenuSerial, 0, 0, 0);
                            Core.SendToServer(selectedData);

                            FinishWork();
                            return CallbackResult.Eat;
                        }

                        // Select option
                        string option = menu.Option.ToLowerInvariant();
                        for (int i = 0; i < packet.Options.Count; i++)
                        {
                            if (packet.Options[i].Text.ToLowerInvariant().Contains(option))
                            {
                                byte[] selectedData = PacketBuilder.ObjectPicked(packet.DialogSerial, packet.MenuSerial, (ushort)(i + 1), packet.Options[i].Artwork, packet.Options[i].Hue);
                                Core.SendToServer(selectedData);

                                FinishWork();
                                return CallbackResult.Eat;
                            }
                        }

                        Trace.WriteLine("Unable to find requested option. Menu passed to client.", "UIManager");
                    }
                    else
                    {
                        Trace.WriteLine("Unexpected menu received. Menu passed to client.", "UIManager");
                    }

                    FinishWork();
                }

                if (CurrentState != State.Ready)
                {
                    Reset();
                }

                return CallbackResult.Normal;
            }
        }

        #endregion

        #region Client actions handling (useskill, useobject, ...)

        private static CallbackResult OnObjectDoubleClick(byte[] data, CallbackResult prevResult)
        {
            lock (syncRoot)
            {
                if (CurrentState != State.Ready && CurrentState != State.WaitTarget && CurrentState != State.WaitMenu)
                {
                    Reset();
                }

                return CallbackResult.Normal;
            }
        }

        private static CallbackResult OnUse(byte[] data, CallbackResult prevResult)
        {
            lock (syncRoot)
            {
                byte command = data[3];

                if (command == 0x24 || command == 0x56 || command == 0x58)
                {
                    if (CurrentState != State.Ready && CurrentState != State.WaitTarget && CurrentState != State.WaitMenu)
                    {
                        Reset();
                    }
                }

                return CallbackResult.Normal;
            }
        }

        private static CallbackResult OnGeneralCommand(byte[] data, CallbackResult prevResult)
        {
            lock (syncRoot)
            {
                ushort subcommand = ByteConverter.LittleEndian.ToUInt16(data, 3);

                if (subcommand == 0x0A || subcommand == 0x09 || subcommand == 0x1C)
                {
                    if (CurrentState != State.Ready && CurrentState != State.WaitTarget && CurrentState != State.WaitMenu)
                    {
                        Reset();
                    }
                }

                return CallbackResult.Normal;
            }
        }

        #endregion

        #region Phoenix-controlled actions

        public static bool MoveItem(uint serial, ushort amount, ushort x, ushort y, sbyte z, uint container)
        {
            if (serial == 0 || serial == UInt32.MaxValue)
                return false;

            if (container == 0) container = UInt32.MaxValue;
            if (amount == 0) amount = UInt16.MaxValue;

            OperationResult result = new OperationResult();

            bool packetsSent = false;
            while (!packetsSent)
            {
                readySignal.WaitOne();

                lock (syncRoot)
                {
                    if (CurrentState == State.Ready)
                    {
                        Core.SendToServer(PacketBuilder.ItemPickupRequest(serial, amount));
                        Core.SendToServer(PacketBuilder.ItemDropRequest(serial, x, y, z, container));

                        operationResult = result;
                        PickedUpItem = serial;

                        CurrentState = State.MoveItem;
                        BeginTimeout(PhoenixMoveItemTimeout);

                        packetsSent = true;
                    }
                }
            }

            result.Event.WaitOne();
            return result.Success;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serial">Equipped item serial.</param>
        /// <param name="character">Serial of character that is item equipped to.</param>
        /// <param name="layer">Layer to what item should be equipped. Mostly ignored by servers.</param>
        /// <returns></returns>
        public static bool EquipItem(uint serial, uint character, byte layer)
        {
            if (serial == 0 || serial == UInt32.MaxValue)
                return false;

            OperationResult result = new OperationResult();

            bool packetsSent = false;
            while (!packetsSent)
            {
                readySignal.WaitOne();

                lock (syncRoot)
                {
                    if (CurrentState == State.Ready)
                    {
                        Core.SendToServer(PacketBuilder.ItemPickupRequest(serial, 1));
                        Core.SendToServer(PacketBuilder.ItemEquipRequest(serial, character, layer));

                        operationResult = result;
                        PickedUpItem = serial;

                        CurrentState = State.MoveItem;
                        BeginTimeout(PhoenixMoveItemTimeout);

                        packetsSent = true;
                    }
                }
            }

            result.Event.WaitOne();
            return result.Success;
        }

        public static uint TargetObject()
        {
            TargetInfo info = new TargetInfo();
            info.TargetId = (uint)new Random().Next();

            OperationResult result = new OperationResult();

            lock (syncRoot)
            {
                if (CurrentState != State.Ready)
                {
                    Reset();
                }

                Debug.Assert(CurrentState == State.Ready, "CurrentState is not Ready. Internal error.");

                Core.SendToClient(info.ToData());

                targetInfo = info;
                operationResult = result;
                CurrentState = State.Target;
                BeginTimeout(PhoenixTargetTimeout);
            }

            result.Event.WaitOne();

            if (info.Serial == 0)
                info.Serial = Serial.Invalid;

            Debug.WriteLine("Client returned object target. Serial=0x" + info.Serial.ToString("X8"), "UIManager");
            return info.Serial;
        }

        public static TargetInfo Target()
        {
            TargetInfo info = new TargetInfo();
            info.Type = 1;
            info.TargetId = (uint)new Random().Next();
            info.X = 0xFFFF;
            info.Y = 0xFFFF;

            OperationResult result = new OperationResult();

            lock (syncRoot)
            {
                if (CurrentState != State.Ready)
                {
                    Reset();
                }

                Debug.Assert(CurrentState == State.Ready, "CurrentState is not Ready. Internal error.");

                Core.SendToClient(info.ToData());

                targetInfo = info;
                operationResult = result;
                CurrentState = State.Target;
                BeginTimeout(PhoenixTargetTimeout);
            }

            result.Event.WaitOne();

            Debug.WriteLine(String.Format("Client returned target: Serial=0x{0:X8} X={1} Y={2} Z={3} Graphic=0x{4:X4}",
                                          info.Serial, info.X, info.Y, info.Z, info.Graphic), "UIManager");

            return info;
        }

        public static void WaitForTarget(TargetInfo target)
        {
            WaitForTarget(targetInfo.Serial, target.X, target.Y, target.Z, target.Graphic);
        }

        public static void EnqueueWaitForTarget(TargetInfo target)
        {
            EnqueueWaitForTarget(targetInfo.Serial, target.X, target.Y, target.Z, target.Graphic);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serial">Object serial or zero to specify ground.</param>
        /// <param name="x">X position on ground. Ignored when nonzero serial.</param>
        /// <param name="y">Y position on ground. Ignored when nonzero serial.</param>
        /// <param name="z">Z position on ground. Ignored when nonzero serial.</param>
        /// <param name="graphic">Graphic of static, or 0 for map tile. Ignored when nonzero serial.</param>
        public static void WaitForTarget(uint serial, ushort x, ushort y, sbyte z, ushort graphic)
        {
            TargetInfo info = new TargetInfo();
            info.Serial = serial;

            if (serial == 0)
            {
                info.Type = 1;
                info.X = x;
                info.Y = y;
                info.Z = z;
                info.Graphic = graphic;
            }

            lock (syncRoot)
            {
                if (CurrentState != State.Ready)
                {
                    Reset();
                }

                Debug.Assert(CurrentState == State.Ready, "CurrentState is not Ready. Internal error.");

                waitQueue = new Queue<WaitQuery>();
                waitQueue.Enqueue(new WaitQuery(info));
                CurrentState = State.WaitTarget;

                BeginTimeout(WaitTargetTimeout);
            }
        }

        public static void EnqueueWaitForTarget(uint serial, ushort x, ushort y, sbyte z, ushort graphic)
        {
            TargetInfo info = new TargetInfo();
            info.Serial = serial;

            if (serial == 0)
            {
                info.Type = 1;
                info.X = x;
                info.Y = y;
                info.Z = z;
                info.Graphic = graphic;
            }

            lock (syncRoot)
            {
                if ((CurrentState != State.WaitMenu && CurrentState != State.WaitTarget) ||
                    waitQueue.Peek().ThreadId != Thread.CurrentThread.ManagedThreadId)
                {
                    Reset();

                    waitQueue = new Queue<WaitQuery>();
                    CurrentState = State.WaitTarget;
                }

                Debug.Assert(waitQueue != null, "waitQueue == null");

                waitQueue.Enqueue(new WaitQuery(info));

                Debug.WriteLine("Target enqueued.", "UIManager");

                BeginTimeout(WaitTargetTimeout);
            }
        }

        public static void WaitForMenu(params MenuSelection[] menus)
        {
            lock (syncRoot)
            {
                if (CurrentState != State.Ready)
                {
                    Reset();
                }

                Debug.Assert(CurrentState == State.Ready, "CurrentState is not Ready. Internal error.");

                waitQueue = new Queue<WaitQuery>();

                for (int i = 0; i < menus.Length; i++)
                {
                    waitQueue.Enqueue(new WaitQuery(menus[i]));
                }

                CurrentState = State.WaitMenu;
                BeginTimeout(WaitMenuTimeout);
            }
        }

        public static void EnqueueWaitForMenu(params MenuSelection[] menus)
        {
            lock (syncRoot)
            {
                if ((CurrentState != State.WaitMenu && CurrentState != State.WaitTarget) ||
                    waitQueue.Peek().ThreadId != Thread.CurrentThread.ManagedThreadId)
                {
                    Reset();

                    waitQueue = new Queue<WaitQuery>();
                    CurrentState = State.WaitMenu;
                }

                Debug.Assert(waitQueue != null, "waitQueue == null");

                for (int i = 0; i < menus.Length; i++)
                {
                    waitQueue.Enqueue(new WaitQuery(menus[i]));
                }

                Debug.WriteLine("MenuSelection items enqueued.", "UIManager");

                BeginTimeout(WaitMenuTimeout);
            }
        }

        #endregion

        public static void Reset()
        {
            ResetInternal(false);
        }

        public static void ResetInternal(bool timeout)
        {
            lock (syncRoot)
            {
                switch (CurrentState)
                {
                    case State.Ready:
                        return;

                    case State.ClientPickedUpItem:
                    case State.ClientHoldingItem:
                        Core.SendToClient(PacketBuilder.PickupItemFailed(6));
                        Core.SendToServer(PacketBuilder.ItemDropRequest(PickedUpItem, 0xFFFF, 0xFFFF, 0, 0));

                        pickedUpItemName = null;
                        PickedUpItem = 0;
                        break;

                    case State.ClientDroppedItem:
                        pickedUpItemName = null;
                        PickedUpItem = 0;
                        break;

                    case State.ServerTarget:
                        Debug.Assert(targetInfo != null);
                        targetInfo.X = 0xFFFF;
                        targetInfo.Y = 0xFFFF;
                        targetInfo.Z = 0;
                        targetInfo.Serial = 0;
                        targetInfo.Graphic = 0;
                        Core.SendToServer(targetInfo.ToData());
                        targetInfo.Flags = 0x03;
                        Core.SendToClient(targetInfo.ToData());
                        targetInfo = null;
                        break;

                    case State.MoveItem:
                        Debug.Assert(operationResult != null);
                        operationResult.Success = false;
                        operationResult.Event.Set();
                        operationResult = null;
                        PickedUpItem = 0;
                        break;

                    case State.Target:
                        Debug.Assert(operationResult != null);
                        operationResult.Event.Set();
                        operationResult = null;
                        targetInfo = null;
                        break;

                    case State.WaitTarget:
                        break;

                    case State.WaitMenu:
                        break;

                    default:
                        Trace.WriteLine("Unhandled state in UIManager.Cancel()!!! Please report this error.", "UIManager");
                        return;
                }

                waitQueue = null;
                CurrentState = State.Ready;
                readySignal.Set();

                if (timeout)
                    timeoutThread = null;
                else
                    StopTimeout();
            }
        }
    }
}
