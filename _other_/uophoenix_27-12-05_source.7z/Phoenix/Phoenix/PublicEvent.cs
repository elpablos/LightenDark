using System;
using System.Collections.Generic;
using System.Text;
using Phoenix.Runtime;

namespace Phoenix
{
    public class PublicEvent<THandler, TEventArgs> : IAssemblyObjectList
        where TEventArgs : EventArgs
    {
        private class EventObject : IAssemblyObject
        {
            private Delegate handler;

            public EventObject(object eventHandler)
            {
                handler = (Delegate)eventHandler;
            }

            public Delegate Handler
            {
                get { return handler; }
            }

            System.Reflection.Assembly IAssemblyObject.Assembly
            {
                get { return handler.Method.DeclaringType.Assembly; }
            }

            public override int GetHashCode()
            {
                return handler.GetHashCode();
            }

            public override bool Equals(object obj)
            {
                if (obj == null || obj.GetType() != GetType())
                    return false;
                return handler.Equals(((EventObject)obj).handler);
            }
        }

        private List<Delegate> handlerList = new List<Delegate>();

        public PublicEvent()
        {
            if (!typeof(THandler).IsSubclassOf(typeof(Delegate)))
                throw new InvalidOperationException("_Handler must be Delegate.");
        }

        public int HandlerCount
        {
            get { return handlerList.Count; }
        }

        public void Invoke(object sender, TEventArgs e)
        {
            for (int i = 0; i < handlerList.Count; i++)
            {
                SyncEvent.InvokeSingle(handlerList[i], sender, e);
            }
        }

        public void AddHandler(THandler handler)
        {
            RuntimeCore.AddAssemblyObject(new EventObject(handler), this);
            handlerList.Add((Delegate)(object)handler);
        }

        public void RemoveHandler(THandler handler)
        {
            handlerList.Remove((Delegate)(object)handler);
            RuntimeCore.RemoveAssemblyObject(new EventObject(handler));
        }

        void IAssemblyObjectList.Remove(IAssemblyObject obj)
        {
            EventObject eventObject = obj as EventObject;
            if (eventObject != null)
            {
                handlerList.Remove(eventObject.Handler);
            }
        }
    }

    /// <summary>
    /// Equal to PublicEvent with EventHandler and EventArgs.
    /// </summary>
    public class DefaultPublicEvent : PublicEvent<EventHandler, EventArgs>
    {
    }
}
